"""Offline end-to-end checks of the nested search on synthetic expression
data: every algorithm runs on the binary panel problem built by the
pipeline, and the GO-coherence score behaves as documented."""
import numpy as np
import pandas as pd
import pytest
from pymoo.optimize import minimize

from dn_moea import objectives
from dn_moea.objectives import GOCoherenceScorer
from dn_moea.preprocessing import build_candidate_pool
from dn_moea.sampling import HarmonicSparseSampling
from scripts.experiments.run_nested_ablation_study import (
    ALGORITHMS,
    NestedPanelProblem,
    evaluate_outer,
    make_algorithm,
    representative,
)


def synthetic_cohort(n_genes=60, n_cases=20, n_controls=12, n_signal=8, seed=0):
    rng = np.random.default_rng(seed)
    genes = [f"G{i}" for i in range(n_genes)]
    samples = [f"S{i}" for i in range(n_cases + n_controls)]
    labels = pd.Series([1] * n_cases + [0] * n_controls, index=samples, name="label")
    values = rng.normal(size=(n_genes, len(samples)))
    values[:n_signal, :n_cases] += 2.0
    return pd.DataFrame(values, index=genes, columns=samples), labels


@pytest.mark.parametrize("name", ALGORITHMS)
def test_algorithm_runs_on_panel_problem(name):
    expression, labels = synthetic_cohort()
    pool = expression.index[:30].tolist()
    problem = NestedPanelProblem(
        pool, expression, labels,
        go_mode="none", go_seed=0, cv_splits=3, cv_repeats=1, random_state=0,
    )
    algorithm = make_algorithm(name, problem.n_obj, 20, len(pool), None)
    result = minimize(problem, algorithm, termination=("n_eval", 120), seed=1, verbose=False)

    F = np.atleast_2d(result.F)
    X = np.atleast_2d(result.X)
    assert F.shape[1] == 2
    assert np.all(np.isfinite(F))
    panel, _ = representative(F, X, pool)
    assert panel and set(panel) <= set(pool)
    auc, ba = evaluate_outer(panel, expression, labels, expression, labels)
    assert 0.0 <= auc <= 1.0 and 0.0 <= ba <= 1.0


def test_candidate_pool_finds_signal_genes():
    expression, labels = synthetic_cohort()
    pool = build_candidate_pool(expression, labels, expression.index)
    assert {f"G{i}" for i in range(8)} <= set(pool)


def test_harmonic_sampling_is_sparse_and_nonempty():
    class Dummy:
        n_var = 500

    X = HarmonicSparseSampling()._do(Dummy(), 200, random_state=np.random.default_rng(0))
    sizes = X.sum(axis=1)
    assert sizes.min() >= 1
    assert np.median(sizes) < 250


def test_go_coherence_score(monkeypatch):
    sets = (
        ("t1", frozenset({"A", "B", "C"})),
        ("t2", frozenset({"A", "B", "D"})),
        ("t3", frozenset({"E", "F", "G"})),
    )
    monkeypatch.setattr(objectives, "_load_gene_sets", lambda: sets)
    scorer = GOCoherenceScorer(list("ABCDEFG"), max_term_fraction=1.0)
    assert scorer.score(["A"]) == 0.0
    assert scorer.score(["A", "B"]) == pytest.approx(1.0)
    assert scorer.score(["A", "E"]) == 0.0
    assert 0.0 < scorer.score(["A", "B", "C"]) < 1.0
