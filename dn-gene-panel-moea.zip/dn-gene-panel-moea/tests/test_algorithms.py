import numpy as np
import pytest

from dn_moea.algorithms.moead_nrd import replacement_scope
from dn_moea.algorithms.nsga2_tiebreak import BalancedRankAndCrowding
from dn_moea.algorithms.spea2_plus import _completion_removal_order
from scripts.experiments.run_nested_ablation_study import ALGORITHMS, make_algorithm


@pytest.mark.parametrize("name", ALGORITHMS)
@pytest.mark.parametrize("n_obj", [2, 3])
def test_algorithm_constructs(name, n_obj):
    algo = make_algorithm(name, n_obj, pop_size=12, n_var=40, max_panel_size=None)
    assert algo is not None


def test_balanced_select_respects_group_sizes_and_count():
    # 3 distinct objective values with 4, 4, 2 members respectively (10 total)
    F = np.array(
        [[0, 0]] * 4 + [[1, 1]] * 4 + [[2, 2]] * 2,
        dtype=float,
    )
    rng = np.random.default_rng(0)

    selected = BalancedRankAndCrowding._balanced_select(F, n_select=6, random_state=rng)

    assert len(selected) == 6
    assert len(set(selected.tolist())) == 6  # no duplicates

    groups = {0: (0, 4), 1: (4, 8), 2: (8, 10)}
    counts_per_group = {
        g: int(np.sum((selected >= lo) & (selected < hi))) for g, (lo, hi) in groups.items()
    }
    # base_quota = 6 // 3 = 2 per group; group 2 only has 2 members so it is
    # capped at 2 -- verifying no group is starved relative to its fair share
    # and no group exceeds its own population size.
    for g, (lo, hi) in groups.items():
        assert counts_per_group[g] <= (hi - lo)
    assert sum(counts_per_group.values()) == 6


def test_balanced_select_all_same_value_falls_back_to_all():
    F = np.zeros((5, 2))
    rng = np.random.default_rng(0)
    selected = BalancedRankAndCrowding._balanced_select(F, n_select=3, random_state=rng)
    assert len(selected) == 3
    assert len(set(selected.tolist())) == 3


def test_select_critical_front_keeps_higher_crowding_groups_unconditionally():
    # Checks the AAAI'25 balanced tie-break rule: a
    # large duplicate-objective-value cluster with strictly higher crowding
    # distance than the boundary must be kept in full, never capped by the
    # balanced-selection quota (that quota only applies to the single group
    # tied at the critical/boundary crowding value).
    F = np.array(
        [[0, 0]] * 5  # 5 individuals, all CD=10 (unique value -> not duplicates
        + [[1, 1]] * 3,  # 3 individuals, all CD=1 (the boundary/critical group)
        dtype=float,
    )
    crowding = np.array([10.0] * 5 + [1.0] * 3)
    rng = np.random.default_rng(0)

    # only 6 slots: the 5 higher-CD individuals must ALL survive unconditionally,
    # leaving exactly 1 slot to be picked from the 3-member boundary group.
    selected = BalancedRankAndCrowding._select_critical_front(F, crowding, n_select=6, random_state=rng)

    assert len(selected) == 6
    assert len(set(selected.tolist())) == 6
    assert set(range(5)).issubset(set(selected.tolist()))  # the higher-CD group is fully kept
    assert sum(1 for i in selected if i >= 5) == 1  # exactly 1 taken from the boundary group


def test_select_critical_front_exact_fit_needs_no_boundary_group():
    F = np.array([[0, 0]] * 4 + [[1, 1]] * 2, dtype=float)
    crowding = np.array([10.0] * 4 + [1.0] * 2)
    rng = np.random.default_rng(0)

    selected = BalancedRankAndCrowding._select_critical_front(F, crowding, n_select=4, random_state=rng)

    assert sorted(selected.tolist()) == [0, 1, 2, 3]


def test_completion_removal_order_prioritizes_worst_raw_fitness():
    # 4 candidates; R (raw fitness, higher = worse/more dominated) ties at
    # indices 0 and 1 (both R=3); index 2 is the best (R=1), index 3 is R=2.
    R = np.array([3.0, 3.0, 1.0, 2.0])
    pool = np.array([0, 1, 2, 3])

    # distances: make index 0 more "crowded" (smaller nearest-neighbour
    # distance) than index 1, so among the R=3 tie, index 0 is removed first.
    dists = np.array(
        [
            [np.inf, 0.1, 5.0, 5.0],
            [0.1, np.inf, 5.0, 5.0],
            [5.0, 5.0, np.inf, 5.0],
            [5.0, 5.0, 5.0, np.inf],
        ]
    )
    # give index 0 an extra close neighbour to break the 0/1 distance tie
    dists[0, 2] = dists[2, 0] = 0.2

    order = _completion_removal_order(R, dists, pool)
    removal_sequence = pool[order]

    # worst raw fitness (R=3, indices 0 and 1) must be removed before the
    # better ones (R=2 at index 3, R=1 at index 2); within the R=3 tie,
    # index 0 (more crowded) goes before index 1.
    assert list(removal_sequence[:2]) == [0, 1]
    assert removal_sequence[2] == 3
    assert removal_sequence[3] == 2


# MOEA/D-NRD replacement scope (Ma, Ning, Zheng & Zhang, Biomimetics 2025,
# Section 3.1 / Algorithm 2), verified against the paper's full text: an
# offspring that dominates the neighborhood ideal point (NIP) gets
# population-wide replacement scope; one that dominates the neighborhood
# worst point (NWP) but not NIP falls back to neighborhood-only; one that
# dominates neither is discarded. The tests below check all three outcomes.
def test_replacement_scope_population_when_dominates_nip():
    nip = np.array([1.0, 1.0])
    nwp = np.array([5.0, 5.0])
    off_F = np.array([0.5, 0.5])  # dominates both NIP and NWP
    assert replacement_scope(off_F, nip, nwp) == "population"


def test_replacement_scope_neighborhood_when_dominates_nwp_only():
    nip = np.array([1.0, 1.0])
    nwp = np.array([5.0, 5.0])
    off_F = np.array([3.0, 3.0])  # dominates NWP, not NIP
    assert replacement_scope(off_F, nip, nwp) == "neighborhood"


def test_replacement_scope_none_when_dominates_neither():
    nip = np.array([1.0, 1.0])
    nwp = np.array([5.0, 5.0])
    off_F = np.array([7.0, 7.0])  # dominates neither reference point
    assert replacement_scope(off_F, nip, nwp) == "none"
