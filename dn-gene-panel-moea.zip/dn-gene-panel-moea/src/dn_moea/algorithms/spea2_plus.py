"""SPEA2+ (Dang, Opris & Sudholt, PPSN 2026).

Classic SPEA2 assigns each individual a fitness ``SPEA_F = R + D`` where
``R`` (raw fitness) is the summed strength of its dominators and ``D`` is a
density term based on the distance to its *k*-th nearest neighbour only
(``k = floor(sqrt(pop_size))``). When the non-dominated set is *smaller*
than the archive size, SPEA2 fills the remainder ("completion") by taking
the lowest-``SPEA_F`` dominated individuals -- but a single k-th-neighbour
distance is shown by Dang, Opris & Sudholt (2026) to be an insufficient
diversity signal among dominated solutions: entire dense clusters can be
eliminated together ("wipeout").

SPEA2+ changes only the *completion* step: instead of ranking dominated
candidates by ``SPEA_F`` (raw fitness + single k-NN distance), it repeatedly
discards the remaining candidate with the worst raw fitness ``R``, breaking
ties the same way SPEA2's own *truncation* operator already breaks ties
among non-dominated solutions -- by the full chain of pairwise distances
(nearest neighbour first, then 2nd-nearest, 3rd-nearest, ...) -- until the
pool has shrunk to exactly the number of slots needed, and merges what is
left into the archive. Raw fitness (Pareto strength), the truncation
operator for an *over-full* non-dominated set, and offspring generation are
all untouched: only the completion operator changes.
"""
from __future__ import annotations

import numpy as np
from pymoo.algorithms.moo.nsga3 import HyperplaneNormalization
from pymoo.algorithms.moo.spea2 import SPEA2, spea_binary_tournament
from pymoo.core.survival import Survival
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.operators.selection.tournament import TournamentSelection
from pymoo.util.dominator import Dominator
from pymoo.util.misc import vectorized_cdist


def _completion_removal_order(R: np.ndarray, dists: np.ndarray, pool: np.ndarray) -> np.ndarray:
    """Order (as positions into ``pool``) in which candidates should be
    discarded from the completion pool: worst raw fitness R first; ties
    broken by the same nearest-neighbour-distance chain (nearest first,
    then 2nd-nearest, ...) that SPEA2's own truncation operator uses among
    non-dominated solutions.
    """
    D = dists[np.ix_(pool, pool)]
    dist_chain = list(np.sort(D, axis=1).T[::-1])  # farthest-neighbour col first, nearest last
    keys = [*dist_chain, -R[pool]]  # last key = primary key for np.lexsort
    return np.lexsort(keys)


class SPEA2PlusSurvival(Survival):
    """SPEA2 environmental selection with the SPEA2+ completion operator."""

    def __init__(self, normalize: bool = True, filter_infeasible: bool = True) -> None:
        super().__init__(filter_infeasible)
        self.normalize = normalize
        self.norm = None

    def _do(self, problem, pop, *args, n_survive=None, **kwargs):
        F = pop.get("F").astype(float, copy=False)

        M = Dominator().calc_domination_matrix(F)
        S = (M == 1).sum(axis=1)
        R = ((M == -1) * S).sum(axis=1)

        k = min(int(np.sqrt(len(pop))), len(pop) - 1)

        if self.normalize:
            if self.norm is None:
                self.norm = HyperplaneNormalization(F.shape[1])
            self.norm.update(F)
            ideal, nadir = self.norm.ideal_point, self.norm.nadir_point
            _F = (F - ideal) / (nadir - ideal)
            dists = vectorized_cdist(_F, _F, fill_diag_with_inf=True)
        else:
            dists = vectorized_cdist(F, F, fill_diag_with_inf=True)

        sdists = np.sort(dists, axis=1)
        D = 1 / (sdists[:, k] + 2)
        SPEA_F = R + D
        pop.set(SPEA_F=SPEA_F, SPEA_R=R, SPEA_D=D)

        survivors = list(np.where(np.all(M >= 0, axis=1))[0])

        if self.normalize:
            I = vectorized_cdist(self.norm.extreme_points, F[survivors]).argmin(axis=1)  # noqa: E741
            pop[survivors][I].set("SPEA_F", -1.0)

        H = set(survivors)
        rem = np.array([i for i in range(len(pop)) if i not in H])

        if len(survivors) < n_survive:
            n_needed = n_survive - len(survivors)
            pool = rem
            # repeatedly discard the worst-raw-fitness candidate (ties broken
            # by the full nearest-neighbour distance chain) until exactly
            # n_needed candidates remain, then merge them into the archive --
            # this is SPEA2+'s only change relative to vanilla SPEA2.
            while len(pool) > n_needed:
                order = _completion_removal_order(R, dists, pool)
                pool = np.delete(pool, order[0])
            survivors.extend(pool.tolist())
        elif len(survivors) > n_survive:
            # over-full non-dominated set: identical to vanilla SPEA2's
            # truncation operator (unaffected by the SPEA2+ change).
            while len(survivors) > n_survive:
                Dloc = dists[np.ix_(survivors, survivors)]
                i = np.lexsort(np.sort(Dloc, axis=1).T[::-1])[0]
                survivors = [survivors[j] for j in range(len(survivors)) if j != i]

        return pop[survivors]


def make_spea2_plus(pop_size: int = 50, **kwargs) -> SPEA2:
    """SPEA2 configured with the SPEA2+ completion operator.

    Defaults are the continuous-variable operators (SBX/PM); pass
    ``sampling=``/``crossover=``/``mutation=`` in ``kwargs`` to override for a
    different encoding (e.g. binary gene-selection problems) -- ``setdefault``
    is used rather than fixed keyword arguments so an explicit override does
    not collide with these defaults.
    """
    kwargs.setdefault("sampling", FloatRandomSampling())
    kwargs.setdefault("selection", TournamentSelection(spea_binary_tournament))
    kwargs.setdefault("crossover", SBX())
    kwargs.setdefault("mutation", PM())
    kwargs.setdefault("survival", SPEA2PlusSurvival(normalize=True))
    return SPEA2(pop_size=pop_size, **kwargs)
