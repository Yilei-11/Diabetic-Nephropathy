"""NSGA-II with balanced tie-breaking (Doerr, Ivan & Krejca, AAAI 2025).

Classic NSGA-II breaks ties within the "critical" (splitting) front purely
at random once rank and crowding distance are exhausted as criteria. Doerr,
Ivan and Krejca (2025) show that this lets imbalances in how many
individuals share a given objective value propagate into the next
generation, and propose instead selecting as evenly as possible across the
distinct objective values present in the critical front, only falling back
to uniform random selection to fill any remaining slots.

This module re-implements pymoo's ``RankAndCrowding`` survival loop with
that one change isolated to the tie-break step; everything else (dominance
ranking, crowding-distance calculation for non-critical fronts, offspring
generation) is untouched pymoo/NSGA-II behaviour.
"""
from __future__ import annotations

import numpy as np
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.population import Population
from pymoo.core.survival import Survival
from pymoo.operators.survival.rank_and_crowding.metrics import get_crowding_function
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting


class BalancedRankAndCrowding(Survival):
    """Rank-and-crowding survival with balanced (per-objective-value) tie-breaking."""

    def __init__(self, nds=None, crowding_func: str = "cd") -> None:
        super().__init__(filter_infeasible=True)
        self.nds = nds if nds is not None else NonDominatedSorting()
        self.crowding_func = get_crowding_function(crowding_func)

    def _do(self, problem, pop, *args, random_state=None, n_survive=None, **kwargs) -> Population:
        F = pop.get("F").astype(float, copy=False)
        survivors: list[int] = []

        fronts = self.nds.do(F, n_stop_if_ranked=n_survive)

        for k, front in enumerate(fronts):
            front = np.asarray(front)
            # n_remove only affects pruning-style crowding metrics (pcd/mnn/2nn);
            # for the default "cd" metric it is a no-op, so it is safe to always
            # compute crowding over the whole front before deciding the split.
            crowding_of_front = self.crowding_func.do(F[front, :], n_remove=0)

            if len(survivors) + len(front) > n_survive:
                n_remaining = n_survive - len(survivors)
                selected_local = self._select_critical_front(
                    F[front, :], crowding_of_front, n_remaining, random_state
                )
            else:
                selected_local = np.arange(len(front))

            for j, i in enumerate(front):
                pop[i].set("rank", k)
                pop[i].set("crowding", crowding_of_front[j])

            survivors.extend(front[selected_local])

        return pop[survivors]

    @staticmethod
    def _select_critical_front(F_front, crowding, n_select, random_state) -> np.ndarray:
        """Select ``n_select`` indices (into F_front) from the one "critical"
        (splitting) front, following Doerr, Ivan & Krejca (AAAI 2025),
        Algorithm 1: individuals are partitioned into crowding-distance-tied
        groups ``C_1, ..., C_m`` (descending CD); every group with strictly
        higher CD than the boundary is kept unconditionally, and only the
        single boundary group tied at the critical CD value -- the group that
        would overflow the remaining slots -- is balanced-selected across its
        distinct objective-value subgroups (``_balanced_select``).
        """
        # partition front by exact crowding-distance value, descending order
        # (np.unique on -crowding sorts ascending, i.e. crowding descending)
        cd_values, cd_inverse = np.unique(-crowding, return_inverse=True)

        definite: list[int] = []
        boundary_group = None
        for g in range(cd_values.size):
            members = np.flatnonzero(cd_inverse == g)
            if len(definite) + len(members) <= n_select:
                definite.extend(members.tolist())
            else:
                boundary_group = g
                break

        if boundary_group is None:
            # exact fit -- every group fully consumed, no boundary group needed
            return np.array(definite, dtype=int)

        boundary_members = np.flatnonzero(cd_inverse == boundary_group)
        n_needed = n_select - len(definite)
        chosen_from_boundary = BalancedRankAndCrowding._balanced_select(
            F_front[boundary_members], n_needed, random_state
        )
        selected = definite + boundary_members[chosen_from_boundary].tolist()
        return np.array(selected, dtype=int)

    @staticmethod
    def _balanced_select(F_group, n_select, random_state) -> np.ndarray:
        """Select ``n_select`` indices (into ``F_group``, the single
        crowding-distance-tied boundary group) as evenly as possible across
        distinct objective-value subgroups, filling any shortfall uniformly
        at random from the rest of the boundary group -- per Doerr, Ivan &
        Krejca (AAAI 2025): "select the missing number of individuals
        uniformly at random from the remaining population."
        """
        rng = np.random.default_rng() if random_state is None else random_state

        # group rows of F_group by exact objective vector
        _, inverse, counts = np.unique(
            F_group, axis=0, return_inverse=True, return_counts=True
        )
        n_groups = counts.size
        base_quota = n_select // n_groups

        selected: list[int] = []
        for g in range(n_groups):
            members = np.flatnonzero(inverse == g)
            take = min(len(members), base_quota)
            if take > 0:
                chosen = rng.choice(members, size=take, replace=False)
                selected.extend(chosen.tolist())

        # fill any remaining slots (rounding remainder, or groups smaller
        # than the quota) uniformly at random from the rest of the boundary
        # group -- not by crowding distance, per the paper's stated procedure
        remaining_needed = n_select - len(selected)
        if remaining_needed > 0:
            leftover = np.setdiff1d(np.arange(F_group.shape[0]), np.array(selected, dtype=int))
            chosen = rng.choice(leftover, size=remaining_needed, replace=False)
            selected.extend(chosen.tolist())

        return np.array(selected[:n_select], dtype=int)


def make_nsga2_tiebreak(pop_size: int = 50, **kwargs) -> NSGA2:
    """NSGA-II configured with the balanced tie-breaking survival operator."""
    return NSGA2(pop_size=pop_size, survival=BalancedRankAndCrowding(), **kwargs)
