"""Differential-expression screening: reduces the full gene-level expression
matrix down to a manageable candidate pool for the EC search, and restricts
that pool to genes present on BOTH platforms (GSE96804 exon array + GSE30528
3' array) so that any selected panel can always be re-evaluated on the
external validation set.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests


@dataclass(frozen=True)
class DEGResult:
    gene: str
    log_fold_change: float
    t_statistic: float
    p_value: float
    fdr: float


def differential_expression(expr: pd.DataFrame, labels: pd.Series) -> pd.DataFrame:
    """Welch's t-test (unequal variance) for DN (label=1) vs. control
    (label=0) at every gene, with Benjamini-Hochberg FDR correction.

    ``expr`` is genes x samples (already log2-scale, as both GSE96804 and
    GSE30528 are), ``labels`` is indexed the same as ``expr``'s columns.
    """
    dn = expr.loc[:, labels[labels == 1].index]
    ctrl = expr.loc[:, labels[labels == 0].index]

    t_stat, p_val = stats.ttest_ind(dn, ctrl, axis=1, equal_var=False)
    log_fc = dn.mean(axis=1) - ctrl.mean(axis=1)  # already log2-scale -> difference of means = log2FC

    _, fdr, _, _ = multipletests(p_val, method="fdr_bh")

    return pd.DataFrame(
        {
            "log_fold_change": log_fc.to_numpy(),
            "t_statistic": t_stat,
            "p_value": p_val,
            "fdr": fdr,
        },
        index=expr.index,
    ).sort_values("p_value")


def build_candidate_pool(
    expr: pd.DataFrame,
    labels: pd.Series,
    common_genes: pd.Index,
    fdr_threshold: float = 0.05,
    min_abs_log_fc: float = 0.5,
    max_pool_size: int = 2000,
) -> list[str]:
    """Differentially-expressed genes (BH-FDR < ``fdr_threshold`` and
    |log2FC| >= ``min_abs_log_fc``), restricted to genes present in
    ``common_genes`` (the GSE96804/GSE30528 intersection), capped at
    ``max_pool_size`` by strongest p-value if the DEG list is still large.
    This candidate pool is the EC search space -- the optimizer only ever
    selects gene subsets from within it, never from the full ~13-30k genes.
    """
    deg = differential_expression(expr, labels)
    deg = deg.loc[deg.index.intersection(common_genes)]
    deg = deg[(deg["fdr"] < fdr_threshold) & (deg["log_fold_change"].abs() >= min_abs_log_fc)]
    return deg.index[:max_pool_size].tolist()
