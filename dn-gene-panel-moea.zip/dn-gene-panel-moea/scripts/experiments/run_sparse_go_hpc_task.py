"""Run one outer-split task from the final sparse-GO experiment matrix."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from scripts.experiments.run_nested_ablation_study import (
    ALGORITHMS,
    Task,
    run_task,
)


def decode_task(index: int) -> tuple[Task, int]:
    if not 0 <= index < 160:
        raise ValueError("task index must be between 0 and 159")
    if index < 120:
        algorithm = ALGORITHMS[index // 20]
        split = index % 20
        return Task(algorithm, "go_real"), split
    if index < 140:
        return Task("nsga2", "no_go"), index - 120
    return Task("nsga2", "go_randomized"), index - 140


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-index", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-evals", type=int, default=10000)
    args = parser.parse_args()

    task, split = decode_task(args.task_index)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    config = {
        "outer_splits": 5,
        "outer_repeats": 4,
        "inner_splits": 5,
        "inner_repeats": 1,
        "pop_size": 100,
        "max_evals": args.max_evals,
        "max_pool_size": 2000,
        "max_panel_size": None,
        "n_random": 50,
        "outer_seed": 20260920,
        "search_seed": 20261000,
        "control_seed": 20262000,
        "go_seed": 20263000,
        "only_split": split,
    }
    rows, archives = run_task(task, config)
    if len(rows) != 1:
        raise RuntimeError(f"expected one result row, received {len(rows)}")
    stem = f"task_{args.task_index:03d}"
    pd.DataFrame(rows).to_csv(args.output_dir / f"{stem}__representative.csv", index=False)
    pd.DataFrame(archives).to_csv(args.output_dir / f"{stem}__pareto.csv", index=False)
    metadata = {
        "task_index": args.task_index,
        "algorithm": task.algorithm,
        "condition": task.condition,
        "split": split,
        **config,
    }
    (args.output_dir / f"{stem}__metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(
        f"completed task={args.task_index} condition={task.condition} "
        f"algorithm={task.algorithm} split={split} archive={len(archives)}",
        flush=True,
    )


if __name__ == "__main__":
    main()
