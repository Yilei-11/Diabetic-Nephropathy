"""Run one paired initialization-ablation task for NSGA-II."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
import pandas as pd
from pymoo.core.callback import Callback
from pymoo.optimize import minimize
from sklearn.model_selection import RepeatedStratifiedKFold

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.geo_data import load_gse30528, load_gse96804
from dn_moea.preprocessing import build_candidate_pool
from scripts.experiments.run_nested_ablation_study import (
    NestedPanelProblem,
    evaluate_outer,
    make_algorithm,
    representative,
)

INITIALIZERS = ("harmonic", "mean_matched_bernoulli", "iid_harmonic", "dense_bernoulli")
MILESTONES = (100, 500, 1000, 2500, 5000, 10000)


class FrontTrace(Callback):
    def __init__(self, milestones: tuple[int, ...]) -> None:
        super().__init__()
        self.milestones = milestones
        self.rows: list[dict] = []
        self.seen: set[int] = set()
        self.initial_sizes: np.ndarray | None = None

    def notify(self, algorithm) -> None:
        n_eval = int(algorithm.evaluator.n_eval)
        if self.initial_sizes is None and algorithm.pop is not None:
            x_pop = np.asarray(algorithm.pop.get("X"))
            self.initial_sizes = (x_pop >= 0.5).sum(axis=1)
        for milestone in self.milestones:
            if milestone in self.seen or n_eval < milestone:
                continue
            optimum = algorithm.opt
            if optimum is None or len(optimum) == 0:
                continue
            values = np.atleast_2d(np.asarray(optimum.get("F"), dtype=float))
            for solution, f_values in enumerate(values):
                self.rows.append(
                    {
                        "milestone": milestone,
                        "actual_n_eval": n_eval,
                        "solution": solution,
                        "leanness": -float(f_values[0]),
                        "inner_balanced_accuracy": -float(f_values[1]),
                        "go_coherence": -float(f_values[2]),
                    }
                )
            self.seen.add(milestone)


def decode_task(index: int) -> tuple[str, int]:
    if not 0 <= index < 80:
        raise ValueError("task index must be between 0 and 79")
    return INITIALIZERS[index // 20], index % 20


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-index", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-evals", type=int, default=10000)
    args = parser.parse_args()

    initializer, target_split = decode_task(args.task_index)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    expression, labels = load_gse96804()
    external_expression, _ = load_gse30528()
    assay_universe = expression.index.intersection(external_expression.index)
    splitter = RepeatedStratifiedKFold(
        n_splits=5, n_repeats=4, random_state=20260920
    )
    selected = None
    for split_index, indices in enumerate(splitter.split(expression.T, labels)):
        if split_index == target_split:
            selected = indices
            break
    if selected is None:
        raise RuntimeError(f"outer split {target_split} was not generated")
    train_idx, test_idx = selected
    train_samples = expression.columns[train_idx]
    test_samples = expression.columns[test_idx]
    train_expr = expression.loc[:, train_samples]
    test_expr = expression.loc[:, test_samples]
    train_labels = labels.loc[train_samples]
    test_labels = labels.loc[test_samples]
    candidate_pool = build_candidate_pool(
        train_expr, train_labels, assay_universe, max_pool_size=2000
    )

    search_seed = 20261000 + target_split
    problem = NestedPanelProblem(
        candidate_pool,
        train_expr,
        train_labels,
        go_mode="real",
        go_seed=20263000 + target_split,
        cv_splits=5,
        cv_repeats=1,
        random_state=search_seed,
    )
    algorithm = make_algorithm(
        "nsga2",
        problem.n_obj,
        100,
        len(candidate_pool),
        None,
        initializer,
    )
    trace = FrontTrace(tuple(m for m in MILESTONES if m <= args.max_evals))
    started = perf_counter()
    result = minimize(
        problem,
        algorithm,
        termination=("n_eval", args.max_evals),
        seed=search_seed,
        verbose=False,
        save_history=False,
        callback=trace,
    )
    elapsed = perf_counter() - started

    F = np.atleast_2d(np.asarray(result.F, dtype=float))
    X = np.atleast_2d(np.asarray(result.X))
    panel, rep = representative(F, X, candidate_pool)
    outer_auc, outer_ba = evaluate_outer(
        panel, train_expr, train_labels, test_expr, test_labels
    )
    initial_sizes = np.asarray(trace.initial_sizes, dtype=float)
    harmonic_number = float(
        np.sum(1.0 / np.arange(1, len(candidate_pool) + 1, dtype=float))
    )
    expected_initial_size = (
        len(candidate_pool) / 2.0
        if initializer == "dense_bernoulli"
        else len(candidate_pool) / harmonic_number
    )

    representative_row = {
        "initializer": initializer,
        "algorithm": "nsga2",
        "condition": "go_real",
        "split": target_split,
        "repeat": target_split // 5,
        "fold": target_split % 5,
        "train_n": len(train_samples),
        "test_n": len(test_samples),
        "candidate_pool_size": len(candidate_pool),
        "expected_initial_size": expected_initial_size,
        "initial_size_mean": float(initial_sizes.mean()),
        "initial_size_sd": float(initial_sizes.std(ddof=1)),
        "initial_size_min": int(initial_sizes.min()),
        "initial_size_median": float(np.median(initial_sizes)),
        "initial_size_max": int(initial_sizes.max()),
        "panel_size": len(panel),
        "genes": ",".join(panel),
        "inner_balanced_accuracy": -float(F[rep, 1]),
        "go_coherence": -float(F[rep, 2]),
        "outer_auc": outer_auc,
        "outer_balanced_accuracy": outer_ba,
        "n_evaluations": int(result.algorithm.evaluator.n_eval),
        "runtime_seconds": elapsed,
    }

    pareto_rows = []
    for solution, (f_values, vector) in enumerate(zip(F, X)):
        genes = [
            gene
            for gene, selected_gene in zip(candidate_pool, vector)
            if selected_gene >= 0.5
        ]
        pareto_rows.append(
            {
                "initializer": initializer,
                "split": target_split,
                "solution": solution,
                "representative": solution == rep,
                "panel_size": len(genes),
                "genes": ",".join(genes),
                "leanness": -float(f_values[0]),
                "inner_balanced_accuracy": -float(f_values[1]),
                "go_coherence": -float(f_values[2]),
            }
        )

    for row in trace.rows:
        row.update(initializer=initializer, split=target_split)

    stem = f"task_{args.task_index:03d}"
    pd.DataFrame([representative_row]).to_csv(
        args.output_dir / f"{stem}__representative.csv", index=False
    )
    pd.DataFrame(pareto_rows).to_csv(
        args.output_dir / f"{stem}__pareto.csv", index=False
    )
    pd.DataFrame(trace.rows).to_csv(
        args.output_dir / f"{stem}__trace.csv", index=False
    )
    metadata = {
        "task_index": args.task_index,
        "initializer": initializer,
        "split": target_split,
        "algorithm": "nsga2",
        "condition": "go_real",
        "outer_splits": 5,
        "outer_repeats": 4,
        "inner_splits": 5,
        "inner_repeats": 1,
        "pop_size": 100,
        "max_evals": args.max_evals,
        "max_pool_size": 2000,
        "max_panel_size": None,
        "outer_seed": 20260920,
        "search_seed": search_seed,
        "go_seed": 20263000 + target_split,
        "milestones": list(trace.milestones),
    }
    (args.output_dir / f"{stem}__metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(
        f"completed task={args.task_index} initializer={initializer} "
        f"split={target_split} archive={len(pareto_rows)} "
        f"runtime_seconds={elapsed:.1f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
