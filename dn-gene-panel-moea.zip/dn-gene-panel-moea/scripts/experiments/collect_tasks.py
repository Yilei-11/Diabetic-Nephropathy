"""Merge the per-task outputs of ``run_sparse_go_hpc_task.py``.

Writes ``per_split.csv`` (one representative panel per task) and
``pareto_archives.csv`` (all final nondominated solutions), then the summary
tables of ``run_nested_ablation_study.summarize``.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from scripts.experiments.run_nested_ablation_study import summarize  # noqa: E402

ORDER = ["condition", "algorithm", "split"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    representative = sorted(args.task_dir.glob("task_*__representative.csv"))
    pareto = sorted(args.task_dir.glob("task_*__pareto.csv"))
    if not representative:
        raise FileNotFoundError(f"no task outputs in {args.task_dir}")
    per_split = pd.concat([pd.read_csv(f) for f in representative]).sort_values(ORDER)
    archives = pd.concat([pd.read_csv(f) for f in pareto]).sort_values(ORDER + ["solution"])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_split.to_csv(args.output_dir / "per_split.csv", index=False)
    archives.to_csv(args.output_dir / "pareto_archives.csv", index=False)
    summarize(per_split, archives, args.output_dir)
    print(f"{len(representative)} tasks, {len(archives)} archive solutions")


if __name__ == "__main__":
    main()
