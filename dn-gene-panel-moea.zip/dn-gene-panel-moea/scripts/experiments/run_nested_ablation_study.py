"""Leakage-controlled nested-CV study for sparse multiobjective gene panels.

All supervised steps are repeated inside each outer training split. The main
condition uses panel size, inner-CV balanced accuracy, and real GO Biological
Process coherence. The two controls are run only for the selected algorithm:
a two-objective search without GO and a three-objective search with gene labels
permuted over the GO annotation profiles. Representative selection is accuracy
first and GO blind; GO target attainment is evaluated separately on the saved
final nondominated archives.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from itertools import combinations
from math import comb
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd
from pymoo.algorithms.moo.moead import MOEAD
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.spea2 import SPEA2
from pymoo.core.problem import ElementwiseProblem
from pymoo.operators.crossover.pntx import TwoPointCrossover
from pymoo.operators.mutation.bitflip import BitflipMutation
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from scipy.stats import wilcoxon
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.algorithms.moead_nrd import MOEADNRD  # noqa: E402
from dn_moea.algorithms.nsga2_tiebreak import make_nsga2_tiebreak  # noqa: E402
from dn_moea.algorithms.spea2_plus import make_spea2_plus  # noqa: E402
from dn_moea.geo_data import load_gse30528, load_gse96804  # noqa: E402
from dn_moea.objectives import (  # noqa: E402
    GOCoherenceScorer,
    classification_balanced_accuracy,
    leanness,
)
from dn_moea.preprocessing import build_candidate_pool  # noqa: E402
from dn_moea.sampling import (  # noqa: E402
    DenseBernoulliSampling,
    HarmonicSparseSampling,
    IIDHarmonicSampling,
    MeanMatchedBernoulliSampling,
    PanelSizeRepair,
    SparsePanelSampling,
)

ALGORITHMS = ("nsga2", "nsga2_tiebreak", "spea2", "spea2_plus", "moead", "moead_nrd")
CONDITIONS = ("no_go", "go_real", "go_randomized")


class NestedPanelProblem(ElementwiseProblem):
    def __init__(
        self,
        candidate_pool: list[str],
        expression: pd.DataFrame,
        labels: pd.Series,
        *,
        go_mode: str,
        go_seed: int,
        cv_splits: int,
        cv_repeats: int,
        random_state: int,
    ) -> None:
        if go_mode not in {"none", "real", "randomized"}:
            raise ValueError(f"Unknown GO mode: {go_mode}")
        self.candidate_pool = tuple(candidate_pool)
        self.expression = expression.loc[:, labels.index]
        self.labels = labels
        self.go_mode = go_mode
        self.cv_splits = cv_splits
        self.cv_repeats = cv_repeats
        self.random_state = random_state
        self.go_scorer = (
            None
            if go_mode == "none"
            else GOCoherenceScorer(
                self.candidate_pool,
                randomized=go_mode == "randomized",
                random_state=go_seed,
            )
        )
        self._cache: dict[bytes, np.ndarray] = {}
        super().__init__(
            n_var=len(candidate_pool),
            n_obj=2 if go_mode == "none" else 3,
            n_ieq_constr=0,
            xl=0.0,
            xu=1.0,
            vtype=bool,
        )

    def panel_from_vector(self, x: np.ndarray) -> list[str]:
        selected = np.flatnonzero(np.asarray(x) >= 0.5)
        return [self.candidate_pool[i] for i in selected]

    def _evaluate(self, x, out, *args, **kwargs) -> None:
        mask = np.asarray(x) >= 0.5
        key = np.packbits(mask).tobytes()
        cached = self._cache.get(key)
        if cached is not None:
            out["F"] = cached
            return
        panel = self.panel_from_vector(mask)
        if not panel:
            result = np.ones(self.n_obj, dtype=float)
        else:
            accuracy = classification_balanced_accuracy(
                panel,
                self.expression,
                self.labels,
                n_splits=self.cv_splits,
                n_repeats=self.cv_repeats,
                random_state=self.random_state,
            )
            values = [-leanness(panel), -accuracy]
            if self.go_scorer is not None:
                values.append(-self.go_scorer.score(panel))
            result = np.asarray(values, dtype=float)
        self._cache[key] = result
        out["F"] = result


def partitions_for_target(target: int, n_obj: int) -> int:
    p = 1
    while comb(p + n_obj - 1, n_obj - 1) < target:
        p += 1
    return p


def make_algorithm(
    name: str,
    n_obj: int,
    pop_size: int,
    n_var: int,
    max_panel_size: int | None,
    initializer: str = "harmonic",
):
    if max_panel_size is None:
        if initializer == "harmonic":
            sampling = HarmonicSparseSampling()
        elif initializer == "mean_matched_bernoulli":
            sampling = MeanMatchedBernoulliSampling()
        elif initializer == "iid_harmonic":
            sampling = IIDHarmonicSampling()
        elif initializer == "dense_bernoulli":
            sampling = DenseBernoulliSampling()
        else:
            raise ValueError(f"Unknown initializer: {initializer}")
    else:
        sampling = SparsePanelSampling(max_panel_size)
    common = dict(
        sampling=sampling,
        crossover=TwoPointCrossover(prob=0.9),
        mutation=BitflipMutation(prob_var=1.0 / n_var),
    )
    if max_panel_size is not None:
        common["repair"] = PanelSizeRepair(max_panel_size)
    if name == "nsga2":
        return NSGA2(pop_size=pop_size, **common)
    if name == "nsga2_tiebreak":
        return make_nsga2_tiebreak(pop_size=pop_size, **common)
    if name == "spea2":
        return SPEA2(pop_size=pop_size, **common)
    if name == "spea2_plus":
        return make_spea2_plus(pop_size=pop_size, **common)
    p = partitions_for_target(pop_size, n_obj)
    ref_dirs = get_reference_directions("das-dennis", n_obj, n_partitions=p)
    if name == "moead":
        return MOEAD(ref_dirs=ref_dirs, n_neighbors=15, prob_neighbor_mating=0.7, **common)
    if name == "moead_nrd":
        return MOEADNRD(ref_dirs=ref_dirs, n_neighbors=15, prob_neighbor_mating=0.7, **common)
    raise ValueError(name)


def evaluate_outer(
    panel: list[str],
    train_expr: pd.DataFrame,
    train_labels: pd.Series,
    test_expr: pd.DataFrame,
    test_labels: pd.Series,
) -> tuple[float, float]:
    genes = [g for g in panel if g in train_expr.index and g in test_expr.index]
    if not genes:
        return 0.5, 0.5
    x_train = train_expr.loc[genes, train_labels.index].T.to_numpy()
    x_test = test_expr.loc[genes, test_labels.index].T.to_numpy()
    y_train = train_labels.to_numpy()
    y_test = test_labels.to_numpy()
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)
    model = LogisticRegression(max_iter=2000, C=0.1)
    model.fit(x_train, y_train)
    probability = model.predict_proba(x_test)[:, 1]
    prediction = (probability >= 0.5).astype(int)
    return float(roc_auc_score(y_test, probability)), float(balanced_accuracy_score(y_test, prediction))


def representative(F: np.ndarray, X: np.ndarray, pool: list[str]) -> tuple[list[str], int]:
    # Accuracy-first and GO-blind, so the same decision rule is used in all conditions.
    idx = min(range(len(F)), key=lambda i: (float(F[i, 1]), float(F[i, 0]), i))
    panel = [gene for gene, selected in zip(pool, X[idx]) if selected >= 0.5]
    return panel, idx


@dataclass(frozen=True)
class Task:
    algorithm: str
    condition: str


def run_task(task: Task, config: dict) -> tuple[list[dict], list[dict]]:
    expression, labels = load_gse96804()
    external_expression, _ = load_gse30528()
    assay_universe = expression.index.intersection(external_expression.index)
    splitter = RepeatedStratifiedKFold(
        n_splits=config["outer_splits"],
        n_repeats=config["outer_repeats"],
        random_state=config["outer_seed"],
    )
    rows: list[dict] = []
    archive_rows: list[dict] = []
    mode = {"no_go": "none", "go_real": "real", "go_randomized": "randomized"}[task.condition]

    for split_index, (train_idx, test_idx) in enumerate(splitter.split(expression.T, labels)):
        only_split = config.get("only_split")
        if only_split is not None and split_index != int(only_split):
            continue
        train_samples = expression.columns[train_idx]
        test_samples = expression.columns[test_idx]
        train_expr = expression.loc[:, train_samples]
        test_expr = expression.loc[:, test_samples]
        train_labels = labels.loc[train_samples]
        test_labels = labels.loc[test_samples]
        pool = build_candidate_pool(
            train_expr,
            train_labels,
            assay_universe,
            max_pool_size=config["max_pool_size"],
        )
        base = dict(
            algorithm=task.algorithm,
            condition=task.condition,
            split=split_index,
            repeat=split_index // config["outer_splits"],
            fold=split_index % config["outer_splits"],
            train_n=len(train_samples),
            test_n=len(test_samples),
            train_cases=int(train_labels.sum()),
            test_cases=int(test_labels.sum()),
            candidate_pool_size=len(pool),
        )
        if not pool:
            rows.append(
                dict(
                    **base,
                    panel_size=0,
                    genes="",
                    inner_balanced_accuracy=0.5,
                    objective_go_score=np.nan,
                    real_go_score=0.0,
                    outer_auc=0.5,
                    outer_balanced_accuracy=0.5,
                    random_auc_mean=np.nan,
                    random_ba_mean=np.nan,
                    topdeg_auc=0.5,
                    topdeg_ba=0.5,
                    n_evaluations=0,
                )
            )
            continue

        search_seed = config["search_seed"] + split_index
        go_seed = config["go_seed"] + split_index
        problem = NestedPanelProblem(
            pool,
            train_expr,
            train_labels,
            go_mode=mode,
            go_seed=go_seed,
            cv_splits=config["inner_splits"],
            cv_repeats=config["inner_repeats"],
            random_state=search_seed,
        )
        real_go = (
            problem.go_scorer
            if mode == "real"
            else GOCoherenceScorer(pool, randomized=False)
        )
        algorithm = make_algorithm(
            task.algorithm,
            problem.n_obj,
            config["pop_size"],
            len(pool),
            config["max_panel_size"],
            config.get("initializer", "harmonic"),
        )
        result = minimize(
            problem,
            algorithm,
            termination=("n_eval", config["max_evals"]),
            seed=search_seed,
            verbose=False,
            save_history=False,
        )
        F = np.atleast_2d(np.asarray(result.F, dtype=float))
        X = np.atleast_2d(np.asarray(result.X))
        panel, rep = representative(F, X, pool)

        for solution_index, (f_values, vector) in enumerate(zip(F, X)):
            archive_panel = [
                gene for gene, selected in zip(pool, vector) if selected >= 0.5
            ]
            archive_rows.append(
                dict(
                    algorithm=task.algorithm,
                    condition=task.condition,
                    split=split_index,
                    repeat=split_index // config["outer_splits"],
                    fold=split_index % config["outer_splits"],
                    solution=solution_index,
                    representative=solution_index == rep,
                    panel_size=len(archive_panel),
                    genes=",".join(archive_panel),
                    inner_balanced_accuracy=-float(f_values[1]),
                    objective_go_score=(
                        -float(f_values[2]) if problem.n_obj == 3 else np.nan
                    ),
                    real_go_score=real_go.score(archive_panel),
                )
            )

        outer_auc, outer_ba = evaluate_outer(
            panel, train_expr, train_labels, test_expr, test_labels
        )
        topdeg_panel = pool[: len(panel)]
        topdeg_auc, topdeg_ba = evaluate_outer(
            topdeg_panel, train_expr, train_labels, test_expr, test_labels
        )

        rng = np.random.default_rng(
            config["control_seed"] + 1000 * split_index + len(panel)
        )
        random_metrics = [
            evaluate_outer(
                rng.choice(pool, size=len(panel), replace=False).tolist(),
                train_expr,
                train_labels,
                test_expr,
                test_labels,
            )
            for _ in range(config["n_random"])
        ]
        random_array = np.asarray(random_metrics, dtype=float)
        rows.append(
            dict(
                **base,
                panel_size=len(panel),
                genes=",".join(panel),
                inner_balanced_accuracy=-float(F[rep, 1]),
                objective_go_score=(
                    -float(F[rep, 2]) if problem.n_obj == 3 else np.nan
                ),
                real_go_score=real_go.score(panel),
                outer_auc=outer_auc,
                outer_balanced_accuracy=outer_ba,
                random_auc_mean=float(random_array[:, 0].mean()),
                random_ba_mean=float(random_array[:, 1].mean()),
                topdeg_auc=topdeg_auc,
                topdeg_ba=topdeg_ba,
                n_evaluations=int(result.algorithm.evaluator.n_eval),
            )
        )
    return rows, archive_rows


def paired_wilcoxon(diff: np.ndarray) -> float:
    return float(wilcoxon(diff).pvalue) if np.any(diff != 0) else 1.0


def summarize(per_split: pd.DataFrame, archives: pd.DataFrame, output_dir: Path) -> None:
    summary = (
        per_split.groupby(["condition", "algorithm"])
        .agg(
            n_splits=("split", "size"),
            candidate_pool_mean=("candidate_pool_size", "mean"),
            panel_size_mean=("panel_size", "mean"),
            panel_size_sd=("panel_size", "std"),
            inner_ba_mean=("inner_balanced_accuracy", "mean"),
            real_go_mean=("real_go_score", "mean"),
            outer_auc_mean=("outer_auc", "mean"),
            outer_auc_sd=("outer_auc", "std"),
            outer_ba_mean=("outer_balanced_accuracy", "mean"),
            outer_ba_sd=("outer_balanced_accuracy", "std"),
        )
        .reset_index()
    )
    for idx, row in summary.iterrows():
        group = per_split[
            (per_split.condition == row.condition)
            & (per_split.algorithm == row.algorithm)
        ]
        summary.loc[idx, "delta_auc_random_mean"] = (
            group.outer_auc - group.random_auc_mean
        ).mean()
        summary.loc[idx, "delta_auc_topdeg_mean"] = (
            group.outer_auc - group.topdeg_auc
        ).mean()
    summary.to_csv(output_dir / "summary.csv", index=False)

    keyed = per_split.set_index(["condition", "algorithm", "split"])
    comparisons = []
    for algorithm in sorted(per_split.algorithm.unique()):
        available = set(
            per_split.loc[per_split.algorithm == algorithm, "condition"]
        )
        for control in ("no_go", "go_randomized"):
            if {"go_real", control}.issubset(available):
                real = keyed.loc[("go_real", algorithm)].sort_index()
                other = keyed.loc[(control, algorithm)].sort_index()
                common = real.index.intersection(other.index)
                for metric in (
                    "outer_auc",
                    "outer_balanced_accuracy",
                    "panel_size",
                    "real_go_score",
                ):
                    real_values = real.loc[common, metric].to_numpy(dtype=float)
                    control_values = other.loc[common, metric].to_numpy(dtype=float)
                    diff = real_values - control_values
                    comparisons.append(
                        dict(
                            algorithm=algorithm,
                            contrast=f"go_real - {control}",
                            metric=metric,
                            mean_real=float(real_values.mean()),
                            mean_control=float(control_values.mean()),
                            mean_difference=float(diff.mean()),
                            p_raw=paired_wilcoxon(diff),
                        )
                    )
    ablation = pd.DataFrame(comparisons)
    if not ablation.empty:
        ablation["p_holm"] = multipletests(ablation.p_raw, method="holm")[1]
    ablation.to_csv(output_dir / "go_ablation.csv", index=False)

    stability_rows = []
    for (condition, algorithm), group in per_split.groupby(["condition", "algorithm"]):
        counts: dict[str, int] = {}
        for genes in group.genes:
            for gene in str(genes).split(","):
                if gene:
                    counts[gene] = counts.get(gene, 0) + 1
        for gene, count in counts.items():
            stability_rows.append(
                dict(
                    condition=condition,
                    algorithm=algorithm,
                    gene=gene,
                    selected_splits=count,
                    total_splits=len(group),
                    frequency=count / len(group),
                )
            )
    stability = pd.DataFrame(stability_rows)
    if not stability.empty:
        stability = stability.sort_values(
            ["condition", "algorithm", "selected_splits", "gene"],
            ascending=[True, True, False, True],
        )
    stability.to_csv(output_dir / "feature_stability.csv", index=False)

    if not archives.empty:
        archive_summary = (
            archives.groupby(["condition", "algorithm", "split"])
            .agg(
                archive_size=("solution", "size"),
                panel_size_min=("panel_size", "min"),
                panel_size_median=("panel_size", "median"),
                panel_size_max=("panel_size", "max"),
                inner_ba_max=("inner_balanced_accuracy", "max"),
                real_go_max=("real_go_score", "max"),
            )
            .reset_index()
        )
        archive_summary.to_csv(output_dir / "archive_summary.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results" / "sparse_go_threeobjective_2026_09_20",
    )
    parser.add_argument("--outer-splits", type=int, default=5)
    parser.add_argument("--outer-repeats", type=int, default=1)
    parser.add_argument("--inner-splits", type=int, default=5)
    parser.add_argument("--inner-repeats", type=int, default=1)
    parser.add_argument("--pop-size", type=int, default=100)
    parser.add_argument("--max-evals", type=int, default=5000)
    parser.add_argument("--max-pool-size", type=int, default=2000)
    parser.add_argument("--max-panel-size", type=int, default=30)
    parser.add_argument(
        "--unbounded-sparse",
        action="store_true",
        help="Use harmonic sparse initialization with no panel-size repair or upper limit.",
    )
    parser.add_argument(
        "--selected-design",
        action="store_true",
        help="Run real-GO NSGA-II plus its no/random-GO controls.",
    )
    parser.add_argument(
        "--final-design",
        action="store_true",
        help="Run real GO for all algorithms and both GO controls for NSGA-II.",
    )
    parser.add_argument("--n-random", type=int, default=50)
    parser.add_argument("--outer-seed", type=int, default=20260920)
    parser.add_argument("--search-seed", type=int, default=20261000)
    parser.add_argument("--control-seed", type=int, default=20262000)
    parser.add_argument("--go-seed", type=int, default=20263000)
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--algorithms", nargs="+", choices=ALGORITHMS, default=list(ALGORITHMS))
    parser.add_argument("--conditions", nargs="+", choices=CONDITIONS, default=list(CONDITIONS))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    config = vars(args).copy()
    if args.unbounded_sparse:
        config["max_panel_size"] = None
    config["output_dir"] = str(args.output_dir)
    with open(args.output_dir / "config.json", "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, default=str)

    if args.selected_design and args.final_design:
        parser.error("--selected-design and --final-design are mutually exclusive")
    if args.final_design:
        tasks = [Task(algorithm, "go_real") for algorithm in ALGORITHMS]
        tasks.extend(
            [Task("nsga2", "no_go"), Task("nsga2", "go_randomized")]
        )
    elif args.selected_design:
        tasks = [
            Task("nsga2", "go_real"),
            Task("nsga2", "no_go"),
            Task("nsga2", "go_randomized"),
        ]
    else:
        tasks = [Task(a, c) for c in args.conditions for a in args.algorithms]

    rows: list[dict] = []
    archive_rows: list[dict] = []
    with ProcessPoolExecutor(max_workers=args.max_workers) as pool:
        futures = {pool.submit(run_task, task, config): task for task in tasks}
        for future in as_completed(futures):
            task = futures[future]
            task_rows, task_archives = future.result()
            rows.extend(task_rows)
            archive_rows.extend(task_archives)
            pd.DataFrame(rows).sort_values(
                ["condition", "algorithm", "split"]
            ).to_csv(args.output_dir / "per_split.partial.csv", index=False)
            pd.DataFrame(archive_rows).sort_values(
                ["condition", "algorithm", "split", "solution"]
            ).to_csv(args.output_dir / "pareto_archives.partial.csv", index=False)
            print(f"completed {task.condition}/{task.algorithm}", flush=True)

    per_split = pd.DataFrame(rows).sort_values(["condition", "algorithm", "split"])
    archives = pd.DataFrame(archive_rows).sort_values(
        ["condition", "algorithm", "split", "solution"]
    )
    per_split.to_csv(args.output_dir / "per_split.csv", index=False)
    archives.to_csv(args.output_dir / "pareto_archives.csv", index=False)
    summarize(per_split, archives, args.output_dir)
    for partial_path in (
        args.output_dir / "per_split.partial.csv",
        args.output_dir / "pareto_archives.partial.csv",
    ):
        if partial_path.exists():
            partial_path.unlink()
    print(f"saved nested sparse-GO study to {args.output_dir}", flush=True)


if __name__ == "__main__":
    main()
