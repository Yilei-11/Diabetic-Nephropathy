"""Gene recurrence heatmap with readable labels and
selection-stability summary."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import figstyle  # noqa: E402

figstyle.apply(8.5)
ROOT = Path(__file__).resolve().parents[2]
ALGS = ["nsga2", "nsga2_tiebreak", "spea2", "spea2_plus", "moead", "moead_nrd"]
DISPLAY = {"nsga2": "NSGA-II", "nsga2_tiebreak": "NSGA-II\ntie-break", "spea2": "SPEA2",
           "spea2_plus": "SPEA2+", "moead": "MOEA/D", "moead_nrd": "MOEA/D-\nNRD"}
STAB_DISPLAY = {"nsga2": "NSGA-II", "nsga2_tiebreak": "NSGA-II tie-break", "spea2": "SPEA2",
                "spea2_plus": "SPEA2+", "moead": "MOEA/D", "moead_nrd": "MOEA/D-NRD",
                "topdeg_matched": "Top-DEG (matched size)", "rfe_matched": "RFE (matched size)",
                "lasso": "LASSO", "stability_selection": "Stability selection",
                "elastic_net": "Elastic net", "rfecv": "RFECV"}

per = pd.read_csv(ROOT / "results/sparse_go_pairwise_final_20260920/per_split.csv")
main = per[per.condition == "go_real"]
rows = []
for r in main.itertuples():
    for g in str(r.genes).split(","):
        rows.append((r.algorithm, g))
counts = pd.DataFrame(rows, columns=["algorithm", "gene"]).value_counts().unstack(0).fillna(0).astype(int)
counts = counts.reindex(columns=ALGS, fill_value=0)
counts["total"] = counts.sum(axis=1)
top = counts.sort_values(["total"], ascending=False).head(18)

stab = pd.read_csv(ROOT / "results/aggregate/selection_stability.csv").set_index("method")

fig = plt.figure(figsize=(7.2, 4.9))
ax = fig.add_axes([0.10, 0.04, 0.42, 0.80])
mat = top[ALGS].to_numpy()
im = ax.imshow(mat, cmap="Blues", vmin=0, vmax=8, aspect="auto")
ax.set_yticks(range(len(top)))
ax.set_yticklabels(top.index, fontstyle="italic", fontsize=8.5)
ax.set_xticks(range(len(ALGS)))
ax.set_xticklabels([DISPLAY[a] for a in ALGS], fontsize=7.5)
ax.xaxis.tick_top()
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        ax.text(j, i, str(mat[i, j]), ha="center", va="center", fontsize=7.5,
                color="white" if mat[i, j] >= 5 else "black")
for i, t in enumerate(top.total):
    ax.text(len(ALGS) - 0.35, i, f"{t}", ha="left", va="center", fontsize=7.5)
ax.text(len(ALGS) - 0.35, -0.9, "Total", ha="left", va="center", fontsize=7.5, weight="bold")
fig.text(0.01, 0.955, "(a)", fontsize=10, weight="bold")
cax = fig.add_axes([0.68, 0.13, 0.25, 0.022])
cb = fig.colorbar(im, cax=cax, ticks=[0, 2, 4, 6, 8], orientation="horizontal")
cb.set_label("Outer splits selecting the gene (of 20)", fontsize=7.5)

ax2 = fig.add_axes([0.765, 0.34, 0.225, 0.52])
order = ["nsga2", "nsga2_tiebreak", "spea2", "spea2_plus", "moead", "moead_nrd",
         "topdeg_matched", "rfe_matched", "stability_selection", "lasso", "elastic_net", "rfecv"]
order = [o for o in order if o in stab.index]
y = np.arange(len(order))[::-1]
colors = ["#2b6ca3" if o in ALGS else "#b0b0b0" for o in order]
ax2.barh(y, stab.loc[order, "jaccard"], color=colors, height=0.65)
ax2.set_yticks(y)
ax2.set_yticklabels([STAB_DISPLAY[o] for o in order], fontsize=7.3)
ax2.set_xlabel("Mean pairwise Jaccard across 20 splits", fontsize=7.5)
ax2.set_xlim(0, max(0.5, float(stab.loc[order, "jaccard"].max()) * 1.15))
for yy, o in zip(y, order):
    ax2.text(stab.loc[o, "jaccard"] + 0.005, yy, f"{stab.loc[o, 'jaccard']:.3f}", va="center", fontsize=6.8)
fig.text(0.585, 0.955, "(b)", fontsize=10, weight="bold")
ax2.spines[["top", "right"]].set_visible(False)

out = Path(sys.argv[1])
fig.savefig(out)
fig.savefig(out.with_suffix(".png"), dpi=200)
