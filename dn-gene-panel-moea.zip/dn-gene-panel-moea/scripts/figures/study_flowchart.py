"""Study design as a left-to-right flow diagram."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import figstyle  # noqa: E402

figstyle.apply(7.2)

C_DATA = "#dbe9f6"
C_NEST = "#fdf0d5"
C_EVAL = "#e3f1df"
C_ABL = "#efe6f5"
C_EXT = "#fbe1df"
EDGE = "#4a4a4a"


def box(ax, x, y, w, h, title, lines, color, title_size=7.8, size=6.9):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.012",
                                fc=color, ec=EDGE, lw=0.7))
    ax.text(x + 0.008, y + h - 0.012, title, ha="left", va="top", fontsize=title_size, weight="bold")
    ax.text(x + 0.008, y + h - 0.045, "\n".join(lines), ha="left", va="top", fontsize=size,
            linespacing=1.32)


def arrow(ax, p, q, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=8, lw=0.8, color=EDGE,
                                 connectionstyle=f"arc3,rad={rad}"))


fig = plt.figure(figsize=(7.2, 5.3))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")
X1, W1 = 0.010, 0.300
X2, W2 = 0.345, 0.300
X3, W3 = 0.680, 0.310

# Column 1
box(ax, X1, 0.835, W1, 0.150, "Discovery cohort", [
    "GSE96804: HTA 2.0 microarray, micro-",
    "dissected glomeruli; 41 DN, 20 controls",
], C_DATA)
box(ax, X1, 0.605, W1, 0.205, "Outer resampling", [
    "Stratified 5-fold CV repeated 4 times",
    "(20 outer splits; extension to 10 repeats)",
    "Training 48-49 samples, test 12-13",
    "Test fold withheld from all supervised",
    "discovery steps",
], C_DATA)
box(ax, X1, 0.320, W1, 0.255, "Same-split comparators", [
    "50 random panels of equal size",
    "Top-DEG panel of equal size",
    "LASSO and elastic-net logistic regression",
    "RFE (matched size) and RFECV",
    "Stability selection",
    "All use the same training-only pool",
], C_ABL)
box(ax, X1, 0.075, W1, 0.215, "Statistics", [
    "Nadeau-Bengio corrected resampled",
    "t test across 20 splits; Holm adjustment",
    "Wilson and bootstrap 95% intervals",
    "Selection stability: pairwise Jaccard",
    "and Nogueira index",
], C_EVAL)

# Column 2: nested pipeline
ax.add_patch(FancyBboxPatch((X2 - 0.010, 0.325), W2 + 0.020, 0.660,
                            boxstyle="round,pad=0.004,rounding_size=0.015",
                            fc="white", ec=EDGE, lw=0.9, ls=(0, (4, 2))))
ax.text(X2, 0.978, "Repeated inside every outer training split", ha="left", va="top",
        fontsize=7.8, weight="bold", style="italic")
box(ax, X2, 0.765, W2, 0.180, "1  Candidate pool", [
    "Welch t test; BH-FDR < 0.05; |log$_2$FC| \u2265 0.5",
    "Restricted to genes measured on GSE30528",
    "(platform coverage only, no labels)",
    "1052-1352 genes per split",
], C_NEST)
box(ax, X2, 0.545, W2, 0.195, "2  Sparse three-objective MOEA", [
    "Binary panel encoding, no size cap or repair",
    "Harmonic initialization Pr(K = k) = 1/(kH$_m$)",
    "Six MOEAs, 10,000 fitness evaluations",
    "Objectives: leanness, inner-CV balanced",
    "accuracy, GO coherence",
], C_NEST)
box(ax, X2, 0.340, W2, 0.180, "3  Representative panel", [
    "Largest inner-CV balanced accuracy,",
    "then fewest genes (GO blind)",
    "Sensitivity analysis: GO-aware",
    "tolerance rule on the same archive",
], C_NEST)
box(ax, X2, 0.075, W2, 0.215, "4  Held-out outer fold", [
    "Panel fixed before the test fold is used",
    "Scaler and L2 logistic regression (C = 0.1)",
    "fitted on the outer training split",
    "AUC, balanced accuracy, sensitivity and",
    "specificity on the held-out fold",
], C_EVAL)

# Column 3
box(ax, X3, 0.700, W3, 0.285, "NSGA-II ablations", [
    "Initialization: stratified and IID harmonic,",
    "mean-matched and dense Bernoulli, bounded",
    "uniform 1-50, SparseEA score-guided;",
    "full SparseEA algorithm",
    "GO objective: real, removed, or randomized",
    "gene-annotation mapping",
    "Reactome, KEGG and Hallmark coherence",
    "(annotations not used during search)",
], C_ABL)
box(ax, X3, 0.480, W3, 0.195, "Robustness runs", [
    "Four additional search seeds per split",
    "Outer repeats 5-10 (50 splits in total)",
    "Permuted-label null of the full pipeline",
    "DEG screening inside inner folds",
    "Unrestricted gene universe",
], C_ABL)
box(ax, X3, 0.270, W3, 0.185, "5a  Cohort-specific refitting", [
    "GSE30528: HG-U133A 2.0, glomeruli, 9/13",
    "GSE142025: RNA-seq, biopsy or",
    "nephrectomy tissue, 27/9",
    "Gene identities fixed; coefficients refitted",
], C_EXT)
box(ax, X3, 0.075, W3, 0.170, "5b  Locked-model transfer", [
    "Discovery-split coefficients and threshold",
    "applied unchanged; genes z-scored within",
    "each external cohort without labels",
], C_EXT)

# arrows
arrow(ax, (X1 + W1, 0.720), (X2 - 0.002, 0.800))
arrow(ax, (X1 + W1 / 2, 0.835), (X1 + W1 / 2, 0.812))
arrow(ax, (X2 + W2 / 2, 0.765), (X2 + W2 / 2, 0.742))
arrow(ax, (X2 + W2 / 2, 0.545), (X2 + W2 / 2, 0.522))
arrow(ax, (X2 + W2 / 2, 0.340), (X2 + W2 / 2, 0.292))
arrow(ax, (X1 + W1, 0.340), (X2 - 0.002, 0.250))
arrow(ax, (X2 + W2, 0.430), (X3 - 0.002, 0.380))
arrow(ax, (X2 + W2, 0.400), (X3 - 0.002, 0.180))
arrow(ax, (X3 - 0.002, 0.840), (X2 + W2 + 0.012, 0.660))

ax.text(0.5, 0.040, "DN, diabetic nephropathy; CV, cross-validation; DEG, differentially expressed gene; GO, Gene Ontology; "
        "MOEA, multi-objective evolutionary algorithm;", ha="center", va="center", fontsize=6.4, style="italic")
ax.text(0.5, 0.018, "RFE, recursive feature elimination; RFECV, RFE with cross-validated size; "
        "HTA, Human Transcriptome Array.", ha="center", va="center", fontsize=6.4, style="italic")

out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("study_flowchart.pdf")
fig.savefig(out)
fig.savefig(out.with_suffix(".png"), dpi=200)
