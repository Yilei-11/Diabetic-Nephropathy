"""Times New Roman everywhere; fail loudly if the font is missing."""
import os
from pathlib import Path

import matplotlib as mpl
from matplotlib import font_manager

FONT_DIR = Path(os.environ.get("TNR_FONT_DIR", Path.home() / ".local/share/fonts/times-new-roman"))


def apply(base: float = 8.0) -> None:
    files = sorted(FONT_DIR.glob("*.TTF")) + sorted(FONT_DIR.glob("*.ttf"))
    if not files:
        raise FileNotFoundError(f"Times New Roman not found in {FONT_DIR}")
    for f in files:
        font_manager.fontManager.addfont(str(f))
    names = {font_manager.FontProperties(fname=str(f)).get_name() for f in files}
    if "Times New Roman" not in names:
        raise RuntimeError(f"unexpected font names {names}")
    mpl.rcParams.update({
        "font.family": "Times New Roman",
        "mathtext.fontset": "custom",
        "mathtext.rm": "Times New Roman",
        "mathtext.it": "Times New Roman:italic",
        "mathtext.bf": "Times New Roman:bold",
        "axes.unicode_minus": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base + 1,
        "legend.fontsize": base - 1,
        "xtick.labelsize": base - 0.5,
        "ytick.labelsize": base - 0.5,
    })
