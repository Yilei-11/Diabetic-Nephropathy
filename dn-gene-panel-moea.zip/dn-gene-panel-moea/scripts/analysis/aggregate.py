"""Aggregate the nested robustness experiments into analysis tables."""
from __future__ import annotations

import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from pymoo.indicators.hv import HV
from pymoo.indicators.igd import IGD
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results" / "aggregate"
FINAL = ROOT / "results" / "sparse_go_pairwise_final_20260920"
INIT_DIR = ROOT / "results" / "initialization_ablation_20260920"
ALGS = ["nsga2", "nsga2_tiebreak", "spea2", "spea2_plus", "moead", "moead_nrd"]
RATIO = 12.2 / 48.8  # mean test/train ratio of the 20 outer splits


def corrected(diff, ratio=RATIO) -> dict:
    d = np.asarray(diff, float)
    d = d[np.isfinite(d)]
    n = len(d)
    m = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else 0.0
    se = float(np.sqrt((1 / n + ratio) * sd**2))
    crit = float(stats.t.ppf(0.975, n - 1))
    if se == 0:
        p = 1.0 if m == 0 else 0.0
    else:
        p = float(2 * stats.t.sf(abs(m / se), n - 1))
    return dict(n=n, mean_diff=m, ci_low=m - crit * se, ci_high=m + crit * se, p_raw=p)


def holm(df: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    df = df.copy()
    df["p_holm"] = np.nan
    for _, idx in df.groupby(by).groups.items():
        df.loc[idx, "p_holm"] = multipletests(df.loc[idx, "p_raw"], method="holm")[1]
    return df


def genes(s) -> set[str]:
    return {g for g in str(s).split(",") if g and g != "nan"}


def jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if (a | b) else 1.0


def mean_pairwise_jaccard(sets: list[set]) -> float:
    vals = [jaccard(a, b) for a, b in combinations(sets, 2)]
    return float(np.mean(vals)) if vals else np.nan


def nogueira(sets: list[set], universe: list[str]) -> float:
    """Nogueira, Sechidis & Brown (JMLR 2018) stability estimator."""
    idx = {g: i for i, g in enumerate(universe)}
    Z = np.zeros((len(sets), len(universe)))
    for r, s in enumerate(sets):
        for g in s:
            if g in idx:
                Z[r, idx[g]] = 1
    M, d = Z.shape
    p = Z.mean(axis=0)
    s2 = M / (M - 1) * p * (1 - p)
    kbar = Z.sum(axis=1).mean()
    denom = kbar / d * (1 - kbar / d)
    return float(1 - s2.mean() / denom) if denom > 0 else np.nan


def load_runs() -> tuple[pd.DataFrame, pd.DataFrame]:
    rows, arcs = [], []
    for f in sorted((ROOT / "results" / "nested_tasks").glob("task_*.json")):
        obj = json.loads(f.read_text())
        rows.append(obj["row"])
        for a in obj["archive"]:
            arcs.append(a)
    return pd.DataFrame(rows), pd.DataFrame(arcs)


def front_hv_igd(arch: pd.DataFrame, group_col: str) -> pd.DataFrame:
    """Split-wise joint normalization across the compared groups, as in the paper."""
    out = []
    a = arch.copy()
    a["f1"] = -1.0 / (a.panel_size + 1.0)
    a["f2"] = -a.inner_balanced_accuracy
    a["f3"] = -a.real_go_score
    for split, sf in a.groupby("split"):
        F = sf[["f1", "f2", "f3"]].to_numpy(float)
        lo = F.min(axis=0)
        span = F.max(axis=0) - lo
        span[span == 0] = 1
        N = (F - lo) / span
        ref = N[NonDominatedSorting().do(N, only_non_dominated_front=True)]
        hv, igd = HV(ref_point=np.full(3, 1.1)), IGD(ref)
        sf = sf.assign(n1=N[:, 0], n2=N[:, 1], n3=N[:, 2])
        for key, g in sf.groupby(group_col):
            v = g[["n1", "n2", "n3"]].to_numpy(float)
            out.append({"split": split, group_col: key, "hypervolume": float(hv(v)),
                        "igd": float(igd(v)), "archive_size": len(g)})
    return pd.DataFrame(out)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    runs, arcs = load_runs()
    base = pd.read_csv(FINAL / "per_split.csv")
    base_arc = pd.read_csv(FINAL / "pareto_archives.csv")
    main_rows = base[base.condition == "go_real"].copy()
    main_rows["run_seed"] = 0
    main_rows["experiment"] = "original"
    print(runs.experiment.value_counts())

    # ---------------- 1. repeated independent runs -----------------
    seeds = pd.concat([main_rows, runs[runs.experiment == "seeds"]], ignore_index=True)
    seeds.to_csv(OUT / "seeds_per_run.csv", index=False)
    rows = []
    for alg, g in seeds.groupby("algorithm"):
        per_split = g.groupby("split")
        within_sd = per_split[["outer_auc", "outer_balanced_accuracy", "panel_size"]].std(ddof=1).mean()
        split_means = per_split[["outer_auc", "outer_balanced_accuracy", "panel_size", "inner_balanced_accuracy"]].mean()
        jac_within = np.mean([mean_pairwise_jaccard([genes(x) for x in sg.genes]) for _, sg in per_split])
        identical = np.mean([sg.genes.nunique() == 1 for _, sg in per_split])
        rows.append(dict(
            algorithm=alg, n_runs=len(g),
            auc_mean=g.outer_auc.mean(), auc_within_split_sd=within_sd.outer_auc,
            auc_between_split_sd=split_means.outer_auc.std(ddof=1),
            ba_mean=g.outer_balanced_accuracy.mean(), ba_within_split_sd=within_sd.outer_balanced_accuracy,
            size_mean=g.panel_size.mean(), size_within_split_sd=within_sd.panel_size,
            run_mean_auc_min=g.groupby("run_seed").outer_auc.mean().min(),
            run_mean_auc_max=g.groupby("run_seed").outer_auc.mean().max(),
            jaccard_within_split=jac_within, share_splits_identical_panel=identical,
            topdeg_delta_auc=(g.outer_auc - g.topdeg_auc).mean(),
            random_delta_auc=(g.outer_auc - g.random_auc_mean).mean(),
        ))
    pd.DataFrame(rows).to_csv(OUT / "seeds_summary.csv", index=False)
    # run-averaged algorithm contrasts and controls
    avg = seeds.groupby(["algorithm", "split"])[["outer_auc", "outer_balanced_accuracy", "panel_size",
                                                 "topdeg_auc", "random_auc_mean"]].mean()
    tests = []
    for a, b in combinations(ALGS, 2):
        for m in ("outer_auc", "outer_balanced_accuracy", "panel_size"):
            r = corrected(avg.loc[a][m].values - avg.loc[b][m].values)
            tests.append(dict(first=a, second=b, metric=m, **r))
    holm(pd.DataFrame(tests), ["metric"]).to_csv(OUT / "seeds_pairwise.csv", index=False)
    tests = []
    for a in ALGS:
        for ctrl in ("topdeg_auc", "random_auc_mean"):
            r = corrected(avg.loc[a].outer_auc.values - avg.loc[a][ctrl].values)
            tests.append(dict(algorithm=a, control=ctrl, **r))
    holm(pd.DataFrame(tests), ["control"]).to_csv(OUT / "seeds_controls.csv", index=False)
    # HV/IGD per run with joint normalization over all 30 runs in a split
    sa = pd.concat([
        base_arc[base_arc.condition == "go_real"].assign(run_seed=0),
        arcs[arcs.experiment == "seeds"],
    ], ignore_index=True)
    sa["key"] = sa.algorithm + "|" + sa.run_seed.astype(int).astype(str)
    ind = front_hv_igd(sa, "key")
    ind[["algorithm", "run_seed"]] = ind.key.str.split("|", expand=True)
    ind.to_csv(OUT / "seeds_front_indicators.csv", index=False)
    s = ind.groupby(["algorithm", "split"])[["hypervolume", "igd"]].agg(["mean", "std"])
    hv_tab = ind.groupby("algorithm")[["hypervolume", "igd"]].mean()
    hv_tab["hv_within_split_sd"] = s[("hypervolume", "std")].groupby("algorithm").mean()
    hv_tab["igd_within_split_sd"] = s[("igd", "std")].groupby("algorithm").mean()
    hv_tab.to_csv(OUT / "seeds_front_summary.csv")
    hvm = ind.groupby(["algorithm", "split"])[["hypervolume", "igd"]].mean()
    tests = []
    for a, b in combinations(ALGS, 2):
        for m in ("hypervolume", "igd"):
            r = corrected(hvm.loc[a][m].values - hvm.loc[b][m].values)
            tests.append(dict(first=a, second=b, metric=m, **r))
    holm(pd.DataFrame(tests), ["metric"]).to_csv(OUT / "seeds_front_pairwise.csv", index=False)

    # ---------------- 2. extended outer repeats -----------------
    rep = pd.concat([main_rows, runs[runs.experiment == "repeats"]], ignore_index=True)
    rep.to_csv(OUT / "repeats_per_split.csv", index=False)
    rows = []
    ratio = RATIO
    for alg, g in rep.groupby("algorithm"):
        g = g.sort_values("split")
        for n_rep in range(1, 11):
            h = g[g.split < 5 * n_rep]
            r = corrected(h.outer_auc - h.topdeg_auc, ratio)
            rr = corrected(h.outer_auc - h.random_auc_mean, ratio)
            rows.append(dict(algorithm=alg, n_repeats=n_rep, n_splits=len(h),
                             auc_mean=h.outer_auc.mean(), ba_mean=h.outer_balanced_accuracy.mean(),
                             size_mean=h.panel_size.mean(),
                             delta_topdeg=r["mean_diff"], delta_topdeg_lo=r["ci_low"], delta_topdeg_hi=r["ci_high"],
                             p_topdeg=r["p_raw"], delta_random=rr["mean_diff"], p_random=rr["p_raw"]))
    reps = pd.DataFrame(rows)
    for col in ("p_topdeg", "p_random"):
        reps[col + "_holm"] = np.nan
        for n, idx in reps.groupby("n_repeats").groups.items():
            reps.loc[idx, col + "_holm"] = multipletests(reps.loc[idx, col], method="holm")[1]
    reps.to_csv(OUT / "repeats_cumulative.csv", index=False)

    # ---------------- 3. permutation null -----------------
    perm = runs[runs.experiment == "perm"]
    if len(perm):
        pm = perm.groupby("perm")[["outer_auc", "outer_balanced_accuracy", "inner_balanced_accuracy",
                                   "panel_size", "topdeg_auc", "random_auc_mean"]].mean()
        pm.to_csv(OUT / "perm_per_permutation.csv")
        observed = main_rows[(main_rows.algorithm == "nsga2") & (main_rows.split < 5)]
        obs = observed.outer_auc.mean()
        summary = dict(
            n_perm=len(pm), observed_repeat0_auc=obs,
            observed_repeat0_inner_ba=observed.inner_balanced_accuracy.mean(),
            null_auc_mean=pm.outer_auc.mean(), null_auc_sd=pm.outer_auc.std(ddof=1),
            null_auc_p95=pm.outer_auc.quantile(0.95), null_auc_max=pm.outer_auc.max(),
            null_ba_mean=pm.outer_balanced_accuracy.mean(),
            null_inner_ba_mean=pm.inner_balanced_accuracy.mean(),
            null_inner_ba_min=pm.inner_balanced_accuracy.min(),
            null_size_mean=pm.panel_size.mean(),
            empirical_p=(1 + (pm.outer_auc >= obs).sum()) / (1 + len(pm)),
            standard_pool_empty_share=float((perm.standard_pool_size == 0).mean()),
            standard_pool_size_median=float(perm.standard_pool_size.median()),
        )
        pd.Series(summary).to_csv(OUT / "perm_summary.csv")

    # ---------------- 4. inner-fold DEG screening -----------------
    inner = runs[runs.experiment == "innerdeg"]
    rows, tests = [], []
    for alg in ALGS:
        a = main_rows[main_rows.algorithm == alg].set_index("split").sort_index()
        b = inner[inner.algorithm == alg].set_index("split").sort_index()
        if b.empty:
            continue
        overlap = np.mean([jaccard(genes(a.loc[s, "genes"]), genes(b.loc[s, "genes"])) for s in b.index])
        rows.append(dict(algorithm=alg, n=len(b),
                         inner_ba_main=a.inner_balanced_accuracy.mean(), inner_ba_innerdeg=b.inner_balanced_accuracy.mean(),
                         auc_main=a.outer_auc.mean(), auc_innerdeg=b.outer_auc.mean(),
                         ba_main=a.outer_balanced_accuracy.mean(), ba_innerdeg=b.outer_balanced_accuracy.mean(),
                         size_main=a.panel_size.mean(), size_innerdeg=b.panel_size.mean(),
                         topdeg_delta_innerdeg=(b.outer_auc - b.topdeg_auc).mean(),
                         jaccard_with_main=overlap))
        for m in ("outer_auc", "outer_balanced_accuracy", "panel_size", "inner_balanced_accuracy"):
            r = corrected(b.loc[a.index, m].values - a[m].values)
            tests.append(dict(algorithm=alg, metric=m, **r))
        r = corrected(b.outer_auc.values - b.topdeg_auc.values)
        tests.append(dict(algorithm=alg, metric="innerdeg_vs_topdeg_auc", **r))
    pd.DataFrame(rows).to_csv(OUT / "innerdeg_summary.csv", index=False)
    if tests:
        holm(pd.DataFrame(tests), ["metric"]).to_csv(OUT / "innerdeg_tests.csv", index=False)

    # ---------------- 5. unrestricted universe -----------------
    unr = runs[runs.experiment == "unrestricted"]
    if len(unr):
        from nested_task import load_cached
        _, _, gse30528, _ = load_cached()
        a = main_rows[main_rows.algorithm == "nsga2"].set_index("split").sort_index()
        b = unr.set_index("split").sort_index()
        frac_off = np.mean([np.mean([g not in gse30528.index for g in genes(x)]) for x in b.genes])
        any_off = np.mean([any(g not in gse30528.index for g in genes(x)) for x in b.genes])
        res = dict(n=len(b), pool_mean=b.candidate_pool_size.mean(), pool_min=b.candidate_pool_size.min(),
                   pool_max=b.candidate_pool_size.max(),
                   auc_main=a.outer_auc.mean(), auc_unrestricted=b.outer_auc.mean(),
                   ba_main=a.outer_balanced_accuracy.mean(), ba_unrestricted=b.outer_balanced_accuracy.mean(),
                   size_main=a.panel_size.mean(), size_unrestricted=b.panel_size.mean(),
                   share_genes_absent_gse30528=frac_off, share_panels_with_absent_gene=any_off,
                   topdeg_delta=(b.outer_auc - b.topdeg_auc).mean())
        for m in ("outer_auc", "outer_balanced_accuracy", "panel_size"):
            r = corrected(b.loc[a.index, m].values - a[m].values)
            res[f"{m}_diff"] = r["mean_diff"]
            res[f"{m}_p"] = r["p_raw"]
        pd.Series(res).to_csv(OUT / "unrestricted_summary.csv")
        unr.to_csv(OUT / "unrestricted_per_split.csv", index=False)

    # ---------------- 6. extended initializers -----------------
    init_new = runs[runs.experiment == "init"].copy()
    if len(init_new):
        init_new["init_label"] = np.where(init_new.algorithm == "sparseea", "sparseea_full",
                                          "nsga2_" + init_new.initializer)
        reps_old = pd.concat([pd.read_csv(f) for f in sorted(INIT_DIR.glob("task_0[2-7][0-9]__representative.csv"))])
        reps_old["init_label"] = "nsga2_" + reps_old.initializer
        harm = main_rows[main_rows.algorithm == "nsga2"].assign(init_label="nsga2_harmonic")
        cols = ["init_label", "split", "panel_size", "outer_auc", "outer_balanced_accuracy", "inner_balanced_accuracy"]
        reps_all = pd.concat([harm[cols], reps_old[cols], init_new[cols]], ignore_index=True)
        arc_old = pd.concat([pd.read_csv(f) for f in sorted(INIT_DIR.glob("task_0[2-7][0-9]__pareto.csv"))])
        arc_old["init_label"] = "nsga2_" + arc_old.initializer
        arc_old["real_go_score"] = arc_old["go_coherence"]
        arc_h = base_arc[(base_arc.condition == "go_real") & (base_arc.algorithm == "nsga2")].assign(init_label="nsga2_harmonic")
        arc_n = arcs[arcs.experiment == "init"].copy()
        arc_n["init_label"] = np.where(arc_n.algorithm == "sparseea", "sparseea_full", "nsga2_" + arc_n.initializer)
        c2 = ["init_label", "split", "panel_size", "inner_balanced_accuracy", "real_go_score"]
        arc_all = pd.concat([arc_h[c2], arc_old[c2], arc_n[c2]], ignore_index=True)
        ind = front_hv_igd(arc_all, "init_label")
        merged = reps_all.merge(ind, on=["init_label", "split"])
        merged.to_csv(OUT / "init_extended_per_split.csv", index=False)
        summ = merged.groupby("init_label")[["panel_size", "outer_auc", "outer_balanced_accuracy",
                                              "hypervolume", "igd", "archive_size"]].agg(["mean", "std"])
        summ.columns = ["_".join(c) for c in summ.columns]
        summ.to_csv(OUT / "init_extended_summary.csv")
        h = merged[merged.init_label == "nsga2_harmonic"].set_index("split").sort_index()
        tests = []
        for lab in sorted(set(merged.init_label) - {"nsga2_harmonic"}):
            o = merged[merged.init_label == lab].set_index("split").sort_index()
            for m in ("hypervolume", "igd", "outer_auc", "outer_balanced_accuracy", "panel_size"):
                r = corrected(h[m].values - o.loc[h.index, m].values)
                tests.append(dict(control=lab, metric=m, harmonic_mean=h[m].mean(), control_mean=o[m].mean(), **r))
        holm(pd.DataFrame(tests), ["metric"]).to_csv(OUT / "init_extended_tests.csv", index=False)

    # ---------------- 7. baselines vs evolutionary panels -----------------
    bl = pd.read_csv(ROOT / "results" / "baselines" / "baselines_per_split.csv")
    rows, tests = [], []
    for m, g in bl.groupby("method"):
        rows.append(dict(method=m, size_mean=g.panel_size.mean(), size_sd=g.panel_size.std(ddof=1),
                         size_min=g.panel_size.min(), size_max=g.panel_size.max(),
                         auc_mean=g.outer_auc.mean(), auc_sd=g.outer_auc.std(ddof=1),
                         ba_mean=g.outer_balanced_accuracy.mean(), ba_sd=g.outer_balanced_accuracy.std(ddof=1)))
        g = g.set_index("split").sort_index()
        for alg in ALGS:
            a = main_rows[main_rows.algorithm == alg].set_index("split").sort_index()
            for metric in ("outer_auc", "outer_balanced_accuracy"):
                r = corrected(a[metric].values - g.loc[a.index, metric].values)
                tests.append(dict(algorithm=alg, baseline=m, metric=metric, **r))
    pd.DataFrame(rows).to_csv(OUT / "baselines_summary.csv", index=False)
    holm(pd.DataFrame(tests), ["baseline", "metric"]).to_csv(OUT / "baselines_vs_ec.csv", index=False)

    # ---------------- 8. selection stability -----------------
    from nested_task import load_cached  # noqa: F401
    pools = pd.read_pickle(ROOT / "results" / "uncertainty" / "pools_20splits.pkl")
    universe = sorted(set().union(*[set(p) for p in pools.values()]))
    rows = []
    sets_by_method = {a: [genes(x) for x in main_rows[main_rows.algorithm == a].sort_values("split").genes] for a in ALGS}
    nsga_size = main_rows[main_rows.algorithm == "nsga2"].sort_values("split").panel_size.astype(int).tolist()
    sets_by_method["topdeg_matched"] = [set(pools[s][:k]) for s, k in enumerate(nsga_size)]
    for m, g in bl.groupby("method"):
        sets_by_method[m] = [genes(x) for x in g.sort_values("split").genes]
    for m, sets in sets_by_method.items():
        rows.append(dict(method=m, mean_size=np.mean([len(s) for s in sets]),
                         jaccard=mean_pairwise_jaccard(sets), nogueira=nogueira(sets, universe),
                         max_gene_frequency=pd.Series([g for s in sets for g in s]).value_counts().max() / len(sets)))
    pd.DataFrame(rows).to_csv(OUT / "selection_stability.csv", index=False)

    # ---------------- 9. GO-aware tolerance rule -----------------
    rules = pd.read_csv(ROOT / "results" / "go_rule_annotation" / "per_split_rules.csv")
    pr = rules[rules.rule.isin(["accuracy_first", "tolerance_0.025", "tolerance_0.05", "archive_max_go"])]
    summ = pr.groupby(["condition", "algorithm", "rule"])[["panel_size", "real_go", "outer_auc", "outer_ba",
                                                            "Reactome_coherence", "Reactome_random",
                                                            "KEGG_coherence", "KEGG_random",
                                                            "Hallmark_coherence", "Hallmark_random"]].mean()
    summ.to_csv(OUT / "go_rule_summary.csv")
    tests = []
    for (cond, alg), g in pr.groupby(["condition", "algorithm"]):
        acc = g[g.rule == "accuracy_first"].set_index("split").sort_index()
        for rule in ("tolerance_0.025", "tolerance_0.05"):
            t = g[g.rule == rule].set_index("split").sort_index()
            for m in ("real_go", "outer_auc", "outer_ba", "panel_size", "Reactome_coherence", "KEGG_coherence",
                      "Hallmark_coherence"):
                r = corrected(t[m].values - acc.loc[t.index, m].values)
                tests.append(dict(condition=cond, algorithm=alg, rule=rule, metric=m, **r))
        t = g[g.rule == "tolerance_0.025"].set_index("split").sort_index()
        for lib in ("Reactome", "KEGG", "Hallmark"):
            r = corrected(t[f"{lib}_coherence"].values - t[f"{lib}_random"].values)
            tests.append(dict(condition=cond, algorithm=alg, rule="tolerance_0.025_vs_random", metric=f"{lib}_coherence", **r))
    holm(pd.DataFrame(tests), ["condition", "rule", "metric"]).to_csv(OUT / "go_rule_tests.csv", index=False)
    am = rules[rules.rule.str.startswith("archive_max_") & (rules.rule != "archive_max_go")]
    tests = []
    for lib in ("Reactome", "KEGG", "Hallmark"):
        x = am[am.rule == f"archive_max_{lib}"]
        real = x[(x.condition == "go_real") & (x.algorithm == "nsga2")].set_index("split").sort_index()
        for ctrl in ("no_go", "go_randomized"):
            o = x[(x.condition == ctrl) & (x.algorithm == "nsga2")].set_index("split").sort_index()
            r = corrected(real[f"{lib}_coherence"].values - o.loc[real.index, f"{lib}_coherence"].values)
            tests.append(dict(library=lib, contrast=f"go_real - {ctrl}", real_mean=real[f"{lib}_coherence"].mean(),
                              control_mean=o[f"{lib}_coherence"].mean(), **r))
    holm(pd.DataFrame(tests), ["library"]).to_csv(OUT / "independent_archive_tests.csv", index=False)
    print("done")


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    sys.path.insert(0, str(ROOT / "src"))
    sys.path.insert(0, str(ROOT))
    main()
