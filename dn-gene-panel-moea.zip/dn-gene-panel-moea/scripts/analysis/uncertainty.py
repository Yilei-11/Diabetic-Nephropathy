"""Uncertainty, threshold metrics and locked-model transfer for fixed panels.

Input: a CSV with columns ``method, split, genes`` (one panel per outer split).

Outputs per method
1. internal: outer-fold probabilities are recomputed for all 20 splits; each
   GSE96804 patient receives the mean of its four out-of-fold probabilities
   (one per outer repeat).  Pooled AUC with stratified bootstrap 95% CI,
   sensitivity and specificity at 0.5 with Wilson CIs.
2. refit: the published cohort-specific five-fold refitting protocol, now
   also returning sensitivity/specificity; the 20 panel-level out-of-fold
   probabilities are averaged per external patient for a pooled estimate.
3. locked: scaler and coefficients fitted on the GSE96804 outer training
   split are applied unchanged to each external cohort. Because the three
   assays have different scales, every gene is z-scored within the external
   cohort without using labels (cohort-wise standardization); the threshold
   0.5 and the coefficients are not modified. The 20 locked split models are
   also averaged into one locked ensemble score per external patient.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from dn_moea.geo_data import load_gse142025  # noqa: E402
from nested_task import OUTER_SEED, load_cached, outer_splits  # noqa: E402

N_BOOT = 2000


def wilson(k: int, n: int) -> tuple[float, float]:
    if n == 0:
        return np.nan, np.nan
    z = norm.ppf(0.975)
    p = k / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return centre - half, centre + half


def boot_auc(y: np.ndarray, score: np.ndarray, seed: int = 0) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    values = []
    for _ in range(N_BOOT):
        idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
        values.append(roc_auc_score(y[idx], score[idx]))
    return float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5))


def threshold_metrics(y: np.ndarray, prob: np.ndarray, prefix: str) -> dict:
    pred = (prob >= 0.5).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    n_pos, n_neg = int((y == 1).sum()), int((y == 0).sum())
    sens, spec = tp / n_pos, tn / n_neg
    s_lo, s_hi = wilson(tp, n_pos)
    p_lo, p_hi = wilson(tn, n_neg)
    auc = float(roc_auc_score(y, prob))
    a_lo, a_hi = boot_auc(y, prob)
    return {
        f"{prefix}_auc": auc, f"{prefix}_auc_lo": a_lo, f"{prefix}_auc_hi": a_hi,
        f"{prefix}_sens": sens, f"{prefix}_sens_lo": s_lo, f"{prefix}_sens_hi": s_hi,
        f"{prefix}_spec": spec, f"{prefix}_spec_lo": p_lo, f"{prefix}_spec_hi": p_hi,
        f"{prefix}_ba": (sens + spec) / 2,
    }


def fit_predict(x_train, y_train, x_test, test_scaler=None):
    scaler = StandardScaler().fit(x_train)
    model = LogisticRegression(max_iter=2000, C=0.1).fit(scaler.transform(x_train), y_train)
    x_test = (test_scaler or scaler).transform(x_test)
    return model.predict_proba(x_test)[:, 1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--panels", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    panels = pd.read_csv(args.panels)
    expression, labels, gse30528, gse30528_labels = load_cached()
    gse142025, gse142025_labels = load_gse142025()
    external = {"GSE30528": (gse30528, gse30528_labels), "GSE142025": (gse142025, gse142025_labels)}
    splits = outer_splits(expression, labels, 4)

    summary_rows, panel_rows, store = [], [], []
    for method, group in panels.groupby("method", sort=False):
        internal = np.full((len(labels), 4), np.nan)
        refit_prob = {c: [] for c in external}
        locked_prob = {c: [] for c in external}
        for record in group.itertuples():
            split = int(record.split)
            genes = [g for g in str(record.genes).split(",") if g and g != "nan"]
            train_idx, test_idx = splits[split]
            tr, te = expression.columns[train_idx], expression.columns[test_idx]
            x_train = expression.loc[genes, tr].T.to_numpy(float)
            y_train = labels.loc[tr].to_numpy()
            internal[test_idx, split // 5] = fit_predict(
                x_train, y_train, expression.loc[genes, te].T.to_numpy(float)
            )
            for cohort, (cx, cy) in external.items():
                avail = [g for g in genes if g in cx.index]
                y = cy.to_numpy()
                if not avail:
                    refit_prob[cohort].append(np.full(len(y), 0.5))
                    locked_prob[cohort].append(np.full(len(y), 0.5))
                    continue
                xe = cx.loc[avail, cy.index].T.to_numpy(float)
                # cohort-specific refitting (published protocol)
                cv = StratifiedKFold(5, shuffle=True, random_state=OUTER_SEED + split)
                oof = np.zeros(len(y))
                prev_pred = np.zeros(len(y), dtype=int)
                for a, b in cv.split(xe, y):
                    oof[b] = fit_predict(xe[a], y[a], xe[b])
                    prev_pred[b] = (oof[b] >= y[a].mean()).astype(int)
                refit_prob[cohort].append(oof)
                # locked transfer: discovery-split model, cohort-wise z-scoring
                xd = expression.loc[avail, tr].T.to_numpy(float)
                locked = fit_predict(xd, y_train, xe, test_scaler=StandardScaler().fit(xe))
                locked_prob[cohort].append(locked)
                store.append(dict(method=method, split=split, cohort=cohort, refit=oof, locked=locked))
                for kind, prob, pred in (
                    ("refit", oof, (oof >= 0.5).astype(int)),
                    ("refit_prevalence", oof, prev_pred),
                    ("locked", locked, (locked >= 0.5).astype(int)),
                ):
                    sens = float((pred[y == 1] == 1).mean())
                    spec = float((pred[y == 0] == 0).mean())
                    panel_rows.append(dict(
                        method=method, split=split, cohort=cohort, kind=kind,
                        effective_size=len(avail), auc=float(roc_auc_score(y, prob)),
                        sensitivity=sens, specificity=spec, balanced_accuracy=(sens + spec) / 2,
                    ))
        store.append(dict(method=method, internal=internal.copy()))
        y_int = labels.to_numpy()
        row = dict(method=method, n_panels=len(group))
        row.update(threshold_metrics(y_int, np.nanmean(internal, axis=1), "internal_pooled"))
        for cohort, (_, cy) in external.items():
            y = cy.to_numpy()
            row.update(threshold_metrics(y, np.mean(refit_prob[cohort], axis=0), f"{cohort}_refit_pooled"))
            row.update(threshold_metrics(y, np.mean(locked_prob[cohort], axis=0), f"{cohort}_locked_ensemble"))
        summary_rows.append(row)
        print(method, flush=True)

    pd.to_pickle(store, args.output_dir / "probabilities.pkl")
    per_panel = pd.DataFrame(panel_rows)
    per_panel.to_csv(args.output_dir / "per_panel_threshold_metrics.csv", index=False)
    agg = (
        per_panel.groupby(["method", "cohort", "kind"])
        [["auc", "sensitivity", "specificity", "balanced_accuracy"]]
        .agg(["mean", "std", lambda s: s.quantile(0.025), lambda s: s.quantile(0.975)])
    )
    agg.columns = ["_".join(c).replace("<lambda_0>", "p025").replace("<lambda_1>", "p975") for c in agg.columns]
    agg.reset_index().to_csv(args.output_dir / "per_panel_summary.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(args.output_dir / "pooled_summary.csv", index=False)


if __name__ == "__main__":
    main()
