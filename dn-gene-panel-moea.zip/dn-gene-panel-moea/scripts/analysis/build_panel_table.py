"""Collect representative panels (EC algorithms, GO controls, top-DEG) into one table."""
import sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src")); sys.path.insert(0, str(Path(__file__).resolve().parent))
from dn_moea.preprocessing import build_candidate_pool
from nested_task import load_cached, outer_splits

per = pd.read_csv(ROOT / "results/sparse_go_pairwise_final_20260920/per_split.csv")
e, l, x, _ = load_cached()
uni = e.index.intersection(x.index)
pools = {}
for s, (tr, te) in enumerate(outer_splits(e, l, 4)):
    cols = e.columns[tr]
    pools[s] = build_candidate_pool(e.loc[:, cols], l.loc[cols], uni, max_pool_size=2000)
rows = []
for r in per.itertuples():
    name = r.algorithm if r.condition == "go_real" else f"{r.algorithm}_{r.condition}"
    rows.append(dict(method=name, split=r.split, genes=r.genes))
    if r.condition == "go_real" and r.algorithm == "nsga2":
        rows.append(dict(method="topdeg_nsga2size", split=r.split, genes=",".join(pools[r.split][: int(r.panel_size)])))
pd.DataFrame(rows).to_csv(sys.argv[1], index=False)
pd.to_pickle(pools, Path(sys.argv[1]).with_name("pools_20splits.pkl"))
print(pd.DataFrame(rows).method.value_counts())
