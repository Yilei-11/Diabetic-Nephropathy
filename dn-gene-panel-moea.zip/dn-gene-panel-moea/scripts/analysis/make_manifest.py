"""Write the task manifest consumed by ``nested_task.py`` / ``run_manifest.sh``.

960 tasks, one row each:

* ``seeds``        6 algorithms x 20 outer splits x run seeds 1-4
* ``repeats``      6 algorithms x outer splits 20-49 (outer repeats 5-10)
* ``perm``         NSGA-II, label permutations 0-19 x outer splits 0-4
* ``innerdeg``     6 algorithms x 20 outer splits, inner-fold DEG screening
* ``unrestricted`` NSGA-II x 20 outer splits, pool not restricted to GSE30528
* ``init``         per split: NSGA-II + SparseEA init, NSGA-II + bounded
                   uniform init, complete SparseEA
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

ALGORITHMS = ("nsga2", "nsga2_tiebreak", "spea2", "spea2_plus", "moead", "moead_nrd")
COLUMNS = (
    "condition", "initializer", "innerdeg", "unrestricted", "perm",
    "run_seed", "experiment", "algorithm", "split",
)


def task(experiment: str, algorithm: str, split: int, *, initializer: str = "harmonic",
         innerdeg: int = 0, unrestricted: int = 0, perm: float | None = None,
         run_seed: int = 0) -> dict:
    return dict(
        condition="go_real", initializer=initializer, innerdeg=innerdeg,
        unrestricted=unrestricted, perm=perm, run_seed=run_seed,
        experiment=experiment, algorithm=algorithm, split=split,
    )


def build_manifest() -> pd.DataFrame:
    rows = []
    for algorithm in ALGORITHMS:
        for split in range(20):
            for run_seed in range(1, 5):
                rows.append(task("seeds", algorithm, split, run_seed=run_seed))
    for algorithm in ALGORITHMS:
        for split in range(20, 50):
            rows.append(task("repeats", algorithm, split))
    for perm in range(20):
        for split in range(5):
            rows.append(task("perm", "nsga2", split, perm=float(perm)))
    for algorithm in ALGORITHMS:
        for split in range(20):
            rows.append(task("innerdeg", algorithm, split, innerdeg=1))
    for split in range(20):
        rows.append(task("unrestricted", "nsga2", split, unrestricted=1))
    for split in range(20):
        rows.append(task("init", "nsga2", split, initializer="sparseea"))
        rows.append(task("init", "nsga2", split, initializer="bounded_uniform"))
        rows.append(task("init", "sparseea", split, initializer="sparseea"))
    return pd.DataFrame(rows, columns=list(COLUMNS))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("manifest.csv"))
    args = parser.parse_args()
    build_manifest().to_csv(args.output, index=False, lineterminator="\n")


if __name__ == "__main__":
    main()
