"""Paired panel-level tests for refitted and locked external AUC."""
import sys
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from aggregate import ALGS, corrected, holm

ROOT = Path(__file__).resolve().parents[2]
u = pd.read_csv(ROOT / "results/uncertainty/all/per_panel_threshold_metrics.csv")
rows = []
for kind in ("refit", "locked"):
    for cohort in ("GSE30528", "GSE142025"):
        x = u[(u.kind == kind) & (u.cohort == cohort)]
        for alg in ALGS:
            a = x[x.method == alg].set_index("split").sort_index().auc
            for ctrl in (f"topdeg_{alg}", "baseline_lasso", "baseline_rfe_matched", "baseline_stability_selection"):
                b = x[x.method == ctrl].set_index("split").sort_index().auc
                r = corrected(a.values - b.loc[a.index].values)
                rows.append(dict(kind=kind, cohort=cohort, algorithm=alg,
                                 control=ctrl.replace(f"_{alg}", "") if ctrl.startswith("topdeg") else ctrl,
                                 ec_mean=a.mean(), control_mean=b.mean(), **r))
t = holm(pd.DataFrame(rows), ["kind", "cohort", "control"])
t.to_csv(ROOT / "results/aggregate/external_paired_tests.csv", index=False)
print(t.pivot_table(index=["kind", "cohort", "algorithm"], columns="control", values=["mean_diff", "p_holm"]).round(3).to_string())
