#!/bin/bash
# Run all tasks of a manifest in parallel on one machine.
# Usage: bash scripts/analysis/run_manifest.sh manifest.csv results/nested_tasks [n_parallel]
set -euo pipefail
MANIFEST=$1
OUTDIR=$2
NPAR=${3:-8}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
N=$(($(wc -l < "$MANIFEST") - 1))
seq 0 $((N-1)) | xargs -P "$NPAR" -I{} python scripts/analysis/nested_task.py --manifest "$MANIFEST" --index {} --output-dir "$OUTDIR"
