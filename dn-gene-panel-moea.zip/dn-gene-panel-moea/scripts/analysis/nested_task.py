"""Nested robustness experiments for the DN gene-panel study.

One task = one (experiment, algorithm, outer split, run seed) combination.
The code reuses the final nested protocol in
``scripts/experiments/run_nested_ablation_study.py`` and adds the following
variants (task list: ``make_manifest.py``):

* ``seeds``      -- extra independent evolutionary runs per outer split
                    (minimize seed changes, inner CV partition unchanged)
* ``repeats``    -- outer repeats 5-10 of the same RepeatedStratifiedKFold
* ``perm``       -- full nested pipeline on permuted GSE96804 labels
* ``innerdeg``   -- differential-expression screening repeated inside every
                    inner training fold
* ``unrestricted`` -- candidate pool not intersected with GSE30528 coverage
* ``init``       -- additional initializers (SparseEA score-guided init,
                    bounded uniform 1-50) and the full SparseEA algorithm
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.crossover import Crossover
from pymoo.core.mutation import Mutation
from pymoo.core.sampling import Sampling
from pymoo.operators.mutation.nom import NoMutation
from pymoo.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.geo_data import load_gse30528, load_gse96804  # noqa: E402
from dn_moea.objectives import GOCoherenceScorer, leanness  # noqa: E402
from dn_moea.preprocessing import build_candidate_pool, differential_expression  # noqa: E402
from dn_moea.sampling import SparsePanelSampling  # noqa: E402
from scripts.experiments.run_nested_ablation_study import (  # noqa: E402
    NestedPanelProblem,
    evaluate_outer,
    make_algorithm,
    representative,
)

OUTER_SEED = 20260920
SEARCH_SEED = 20261000
CONTROL_SEED = 20262000
GO_SEED = 20263000
PERM_SEED = 20264000
POP_SIZE = 100
MAX_EVALS = 10000


# ---------------------------------------------------------------------------
# Inner-fold differential-expression screening
# ---------------------------------------------------------------------------
class InnerScreenedProblem(NestedPanelProblem):
    """Same objectives, but each inner fold may only use panel genes that pass
    the DEG screen computed on that inner fold's training samples."""

    def __init__(self, *args, assay_universe: pd.Index, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        x = self.expression.loc[list(self.candidate_pool), self.labels.index]
        y = self.labels.to_numpy()
        n_splits = min(self.cv_splits, int(np.bincount(y).min()))
        cv = RepeatedStratifiedKFold(
            n_splits=n_splits, n_repeats=self.cv_repeats, random_state=self.random_state
        )
        self.x_all = x.T.to_numpy(dtype=float)  # samples x pool genes
        self.y_all = y
        self.folds = []
        index_of = {g: i for i, g in enumerate(self.candidate_pool)}
        for train_idx, test_idx in cv.split(self.x_all, y):
            train_cols = self.labels.index[train_idx]
            inner_pool = build_candidate_pool(
                self.expression.loc[:, train_cols],
                self.labels.loc[train_cols],
                pd.Index(self.candidate_pool),
                max_pool_size=2000,
            )
            allowed = np.zeros(len(self.candidate_pool), dtype=bool)
            allowed[[index_of[g] for g in inner_pool]] = True
            self.folds.append((train_idx, test_idx, allowed))

    def _inner_ba(self, mask: np.ndarray) -> float:
        scores = []
        for train_idx, test_idx, allowed in self.folds:
            cols = np.flatnonzero(mask & allowed)
            y_test = self.y_all[test_idx]
            if len(cols) == 0:
                scores.append(0.5)
                continue
            scaler = StandardScaler()
            x_train = scaler.fit_transform(self.x_all[np.ix_(train_idx, cols)])
            x_test = scaler.transform(self.x_all[np.ix_(test_idx, cols)])
            clf = LogisticRegression(max_iter=1000, C=0.1)
            clf.fit(x_train, self.y_all[train_idx])
            pred = clf.predict(x_test)
            recalls = [
                (pred[y_test == c] == c).mean() for c in (0, 1) if np.any(y_test == c)
            ]
            scores.append(float(np.mean(recalls)))
        return float(np.mean(scores))

    def _evaluate(self, x, out, *args, **kwargs) -> None:
        mask = np.asarray(x) >= 0.5
        key = np.packbits(mask).tobytes()
        cached = self._cache.get(key)
        if cached is not None:
            out["F"] = cached
            return
        panel = self.panel_from_vector(mask)
        if not panel:
            result = np.ones(self.n_obj, dtype=float)
        else:
            values = [-leanness(panel), -self._inner_ba(mask)]
            if self.go_scorer is not None:
                values.append(-self.go_scorer.score(panel))
            result = np.asarray(values, dtype=float)
        self._cache[key] = result
        out["F"] = result


# ---------------------------------------------------------------------------
# SparseEA (Tian et al., IEEE TEVC 2020) adapted to binary panel selection
# ---------------------------------------------------------------------------
def sparseea_scores(problem) -> np.ndarray:
    """Evaluate the m single-gene solutions and return the nondominated front
    number of each gene (lower is better), as in SparseEA."""
    from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

    m = problem.n_var
    F = np.zeros((m, problem.n_obj))
    for j in range(m):
        x = np.zeros(m, dtype=bool)
        x[j] = True
        out: dict = {}
        problem._evaluate(x, out)
        F[j] = out["F"]
    fronts = NonDominatedSorting().do(F)
    score = np.zeros(m, dtype=float)
    for rank, front in enumerate(fronts, start=1):
        score[front] = rank
    return score


class SparseEASampling(Sampling):
    """For each individual, repeat rand()*m binary tournaments on the gene
    scores and switch on the winner."""

    def __init__(self, scores: np.ndarray) -> None:
        super().__init__()
        self.scores = scores

    def _do(self, problem, n_samples, **kwargs):
        rng = kwargs.get("random_state") or np.random.default_rng()
        m = problem.n_var
        X = np.zeros((n_samples, m), dtype=bool)
        for i in range(n_samples):
            n_draws = int(rng.random() * m)
            for _ in range(n_draws):
                a, b = rng.integers(0, m, size=2)
                X[i, a if self.scores[a] <= self.scores[b] else b] = True
            if not X[i].any():
                X[i, rng.integers(0, m)] = True
        return X


def _tournament(rng, candidates: np.ndarray, scores: np.ndarray, prefer_low: bool) -> int:
    a, b = rng.choice(candidates, size=2, replace=True)
    if prefer_low:
        return a if scores[a] <= scores[b] else b
    return a if scores[a] >= scores[b] else b


class SparseEAMaskVariation(Crossover):
    """SparseEA mask crossover followed by mask mutation (one child per pair)."""

    def __init__(self, scores: np.ndarray) -> None:
        super().__init__(n_parents=2, n_offsprings=1)
        self.scores = scores

    def _do(self, problem, X, **kwargs):
        rng = kwargs.get("random_state") or np.random.default_rng()
        _, n_matings, m = X.shape
        Y = np.zeros((1, n_matings, m), dtype=bool)
        for k in range(n_matings):
            p = X[0, k].astype(bool)
            q = X[1, k].astype(bool)
            child = p.copy()
            if rng.random() < 0.5:
                diff = np.flatnonzero(p & ~q)
                if len(diff):
                    child[_tournament(rng, diff, self.scores, prefer_low=False)] = False
            else:
                diff = np.flatnonzero(~p & q)
                if len(diff):
                    child[_tournament(rng, diff, self.scores, prefer_low=True)] = True
            if rng.random() < 0.5:
                ones = np.flatnonzero(child)
                if len(ones):
                    child[_tournament(rng, ones, self.scores, prefer_low=False)] = False
            else:
                zeros = np.flatnonzero(~child)
                if len(zeros):
                    child[_tournament(rng, zeros, self.scores, prefer_low=True)] = True
            Y[0, k] = child
        return Y


# ---------------------------------------------------------------------------
def outer_splits(expression: pd.DataFrame, labels: pd.Series, n_repeats: int):
    splitter = RepeatedStratifiedKFold(
        n_splits=5, n_repeats=n_repeats, random_state=OUTER_SEED
    )
    return list(splitter.split(expression.T, labels))


CACHE = ROOT / "data" / "cache"


def load_cached():
    """GEOparse parsing is slow; keep a pickled copy of the gene-level matrices."""
    import pickle

    path = CACHE / "discovery_gse30528.pkl"
    if path.exists():
        with path.open("rb") as handle:
            return pickle.load(handle)
    expression, labels = load_gse96804()
    external_expression, external_labels = load_gse30528()
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with tmp.open("wb") as handle:
        pickle.dump((expression, labels, external_expression, external_labels), handle)
    tmp.rename(path)
    return expression, labels, external_expression, external_labels


def run_one(spec: dict) -> tuple[dict, list[dict]]:
    t0 = time.perf_counter()
    expression, labels, external_expression, _ = load_cached()
    if spec.get("perm") is not None:
        rng = np.random.default_rng(PERM_SEED + int(spec["perm"]))
        labels = pd.Series(rng.permutation(labels.to_numpy()), index=labels.index, name="label")
    if spec.get("unrestricted"):
        assay_universe = expression.index
    else:
        assay_universe = expression.index.intersection(external_expression.index)

    split = int(spec["split"])
    n_repeats = max(4, split // 5 + 1)
    train_idx, test_idx = outer_splits(expression, labels, n_repeats)[split]
    train_samples = expression.columns[train_idx]
    test_samples = expression.columns[test_idx]
    train_expr = expression.loc[:, train_samples]
    test_expr = expression.loc[:, test_samples]
    train_labels = labels.loc[train_samples]
    test_labels = labels.loc[test_samples]
    pool = build_candidate_pool(train_expr, train_labels, assay_universe, max_pool_size=2000)
    standard_pool_size = len(pool)
    if spec.get("perm") is not None:
        # Under permuted labels the FDR screen is usually empty, which would make
        # the null trivially 0.5. Use the 1206 genes with the smallest Welch P
        # (the mean real-label pool size) so that the search still runs.
        deg = differential_expression(train_expr.loc[train_expr.index.intersection(assay_universe)], train_labels)
        pool = deg.index[:1206].tolist()

    search_seed = SEARCH_SEED + split
    run_seed = int(spec.get("run_seed", 0))
    minimize_seed = search_seed + 1000 * run_seed
    mode = {"no_go": "none", "go_real": "real", "go_randomized": "randomized"}[
        spec.get("condition", "go_real")
    ]
    problem_cls = InnerScreenedProblem if spec.get("innerdeg") else NestedPanelProblem
    extra = {"assay_universe": assay_universe} if spec.get("innerdeg") else {}
    problem = problem_cls(
        pool,
        train_expr,
        train_labels,
        go_mode=mode,
        go_seed=GO_SEED + split,
        cv_splits=5,
        cv_repeats=1,
        random_state=search_seed,
        **extra,
    )
    real_go = problem.go_scorer if mode == "real" else GOCoherenceScorer(pool)

    initializer = spec.get("initializer", "harmonic")
    algorithm_name = spec["algorithm"]
    budget = MAX_EVALS
    if algorithm_name == "sparseea" or initializer == "sparseea":
        scores = sparseea_scores(problem)
        budget = MAX_EVALS - len(pool)  # single-gene evaluations count toward the budget
        if algorithm_name == "sparseea":
            algorithm = NSGA2(
                pop_size=POP_SIZE,
                sampling=SparseEASampling(scores),
                crossover=SparseEAMaskVariation(scores),
                mutation=NoMutation(),
                eliminate_duplicates=True,
            )
        else:
            algorithm = make_algorithm(algorithm_name, problem.n_obj, POP_SIZE, len(pool), None, "harmonic")
            algorithm.initialization.sampling = SparseEASampling(scores)
    elif initializer == "bounded_uniform":
        algorithm = make_algorithm(algorithm_name, problem.n_obj, POP_SIZE, len(pool), None, "harmonic")
        algorithm.initialization.sampling = SparsePanelSampling(max_size=50, min_size=1)
    else:
        algorithm = make_algorithm(algorithm_name, problem.n_obj, POP_SIZE, len(pool), None, initializer)

    result = minimize(
        problem,
        algorithm,
        termination=("n_eval", budget),
        seed=minimize_seed,
        verbose=False,
        save_history=False,
    )
    F = np.atleast_2d(np.asarray(result.F, dtype=float))
    X = np.atleast_2d(np.asarray(result.X))
    panel, rep = representative(F, X, pool)
    archive = []
    for i, (f, x) in enumerate(zip(F, X)):
        genes = [g for g, s in zip(pool, x) if s >= 0.5]
        archive.append(
            dict(
                solution=i,
                representative=i == rep,
                panel_size=len(genes),
                genes=",".join(genes),
                inner_balanced_accuracy=-float(f[1]),
                objective_go_score=-float(f[2]) if problem.n_obj == 3 else np.nan,
                real_go_score=real_go.score(genes),
            )
        )
    outer_auc, outer_ba = evaluate_outer(panel, train_expr, train_labels, test_expr, test_labels)
    topdeg = pool[: len(panel)]
    topdeg_auc, topdeg_ba = evaluate_outer(topdeg, train_expr, train_labels, test_expr, test_labels)
    rng = np.random.default_rng(CONTROL_SEED + 1000 * split + len(panel))
    random_metrics = np.asarray(
        [
            evaluate_outer(
                rng.choice(pool, size=len(panel), replace=False).tolist(),
                train_expr,
                train_labels,
                test_expr,
                test_labels,
            )
            for _ in range(50)
        ]
    )
    row = dict(
        spec,
        repeat=split // 5,
        fold=split % 5,
        train_n=len(train_samples),
        test_n=len(test_samples),
        candidate_pool_size=len(pool),
        standard_pool_size=standard_pool_size,
        panel_size=len(panel),
        genes=",".join(panel),
        inner_balanced_accuracy=-float(F[rep, 1]),
        real_go_score=real_go.score(panel),
        outer_auc=outer_auc,
        outer_balanced_accuracy=outer_ba,
        random_auc_mean=float(random_metrics[:, 0].mean()),
        random_ba_mean=float(random_metrics[:, 1].mean()),
        topdeg_auc=topdeg_auc,
        topdeg_ba=topdeg_ba,
        archive_size=len(F),
        n_evaluations=int(result.algorithm.evaluator.n_eval) + (MAX_EVALS - budget),
        runtime_seconds=time.perf_counter() - t0,
    )
    for a in archive:
        a.update({k: spec[k] for k in spec})
    return row, archive


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--index", type=int, nargs="+", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    manifest = pd.read_csv(args.manifest)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for index in args.index:
        out = args.output_dir / f"task_{index:05d}.json"
        if out.exists():
            continue
        spec = {
            k: (None if (isinstance(v, float) and np.isnan(v)) else v)
            for k, v in manifest.iloc[index].to_dict().items()
        }
        spec = {k: (int(v) if isinstance(v, (np.integer,)) else v) for k, v in spec.items()}
        row, archive = run_one(spec)
        tmp = out.with_suffix(".tmp")
        tmp.write_text(json.dumps({"row": row, "archive": archive}, default=float))
        tmp.rename(out)
        print(f"done {index} {spec} {row['runtime_seconds']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
