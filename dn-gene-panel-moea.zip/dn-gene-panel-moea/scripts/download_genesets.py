"""Download the Enrichr gene-set libraries used by the pipeline.

GO_Biological_Process_2023 is required by the GO-coherence objective;
Reactome_2022, KEGG_2021_Human and MSigDB_Hallmark_2020 are used by
``scripts/analysis/go_rule_annotation.py``. Files are written as GMT to
``data/external/genesets/``.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "data" / "external" / "genesets"
URL = "https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName={}"
LIBRARIES = (
    "GO_Biological_Process_2023",
    "Reactome_2022",
    "KEGG_2021_Human",
    "MSigDB_Hallmark_2020",
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--libraries", nargs="+", default=list(LIBRARIES))
    parser.add_argument("--force", action="store_true", help="re-download existing files")
    args = parser.parse_args()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for name in args.libraries:
        path = OUT_DIR / f"{name}.gmt"
        if path.exists() and not args.force:
            print(f"exists {path}")
            continue
        with urlopen(URL.format(name), timeout=120) as response:
            data = response.read()
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        print(f"wrote {path} ({len(data)} bytes)")


if __name__ == "__main__":
    main()
