"""MOEA/D-NRD: neighborhood region domination (Ma, Ning, Zheng & Zhang,
*Biomimetics*, 2025).

Classic MOEA/D always compares a newly generated offspring against the
members of its own subproblem neighborhood only (``pop[neighbors[k]]``),
which the authors argue under-uses clearly superior offspring (which could
usefully replace individuals anywhere in the population, not just nearby
ones) and wastes replacement effort on clearly inferior offspring.

MOEA/D-NRD adds two per-neighborhood reference points, recomputed from the
current neighborhood population before each replacement decision:

    NIP (neighborhood ideal point) = component-wise minimum objective values
        among the neighborhood
    NWP (neighborhood worst point) = component-wise maximum objective values
        among the neighborhood

and changes the replacement rule for a new offspring ``y`` (Ma, Ning, Zheng &
Zhang 2025, Section 3.1/3.2 prose and Algorithm 2 -- verified directly against
the published PDF, page 8; the paper's own inline "F(a) < F(b)" shorthand is
used loosely throughout to mean "a dominates b" regardless of numeric
direction, so the prose -- identical in the Section 3.1 walkthrough and the
Section 3.2 lead-in to Algorithm 2 -- is what this implementation follows):

    - if ``y`` dominates NIP ("Region III"): compare/replace against the
      ENTIRE population (the offspring beats even the neighborhood's best
      point, so it shouldn't be limited to improving only its own
      neighborhood)
    - elif ``y`` dominates NWP ("Region II"): fall back to the standard
      neighborhood-only replacement (the offspring beats the neighborhood's
      worst point, so it may still be locally useful, but hasn't earned
      population-wide comparison)
    - otherwise ("Region I"): discard ``y`` -- it doesn't even beat the
      neighborhood's worst point, so no replacement comparisons are spent
      on it

Only this replacement decision changes; decomposition (Tchebycheff/PBI),
neighborhood structure, and offspring generation are all identical to
pymoo's stock ``MOEAD``.

Note on scope: Section 3.1 of the source paper explicitly frames the
strategy "assuming that the multi-objective optimization problem addressed
in this context involves a biobjective minimization problem," and Section 4's
experiments test only ZDT1-4 (all bi-objective) -- no 3+-objective benchmark
is used anywhere in the paper. Applying this to our 3-objective problem
(TIR/LBGI/dose) is therefore our own untested extension of the published
mechanism, not something the original authors validated at this objective
count. (An earlier version of this note incorrectly claimed the paper also
tested tri-objective DTLZ problems -- that claim came from an AI web-page
summary that turned out to be fabricated and was not caught until the actual
PDF was obtained and read directly.) Consistent with this, our own empirical
check (`scripts/verify_algorithm_fidelity.py`) found MOEA/D-NRD performing
*worse* than classic MOEA/D on 3-objective DTLZ2 (mean HV 1.077 vs 1.127,
Wilcoxon p<0.0001, n=30 seeds), plausibly because strict Pareto dominance
against NIP/NWP is much rarer in 3D than 2D, making the "population-wide"
promotion branch fire far less often (0/9009 replacement decisions in one
diagnostic run) than the paper's bi-objective design likely assumes.
"""
from __future__ import annotations

import numpy as np
from pymoo.algorithms.moo.moead import MOEAD


def _dominates(a: np.ndarray, b: np.ndarray) -> bool:
    """True if ``a`` Pareto-dominates ``b`` (minimization)."""
    return bool(np.all(a <= b) and np.any(a < b))


def replacement_scope(off_F: np.ndarray, nip: np.ndarray, nwp: np.ndarray) -> str:
    """The paper's "population type" decision (Algorithm 2 / Section 3.1):
    ``"population"`` if the offspring dominates the neighborhood ideal point
    (Region III), ``"neighborhood"`` if it dominates the neighborhood worst
    point but not the ideal point (Region II), else ``"none"`` (Region I,
    discard).
    """
    if _dominates(off_F, nip):
        return "population"
    if _dominates(off_F, nwp):
        return "neighborhood"
    return "none"


class MOEADNRD(MOEAD):
    """MOEA/D with the neighborhood-region-domination replacement rule."""

    def _replace(self, k: int, off) -> None:
        pop = self.pop
        neighbors = self.neighbors[k]
        neighborhood_F = pop[neighbors].get("F")

        nip = neighborhood_F.min(axis=0)
        nwp = neighborhood_F.max(axis=0)

        scope = replacement_scope(off.F, nip, nwp)
        if scope == "population":
            candidates = np.arange(len(pop))
        elif scope == "neighborhood":
            candidates = neighbors
        else:
            return  # beats neither reference point: discard, no comparisons spent

        self._decomposed_replace(candidates, off)

    def _decomposed_replace(self, candidates: np.ndarray, off) -> None:
        """Replace every candidate whose own weight vector the offspring
        beats, in decomposed (scalarized) objective space -- identical
        scalarization logic to stock MOEA/D's ``_replace``, just applied to
        an arbitrary candidate index set instead of always the neighborhood.
        """
        pop = self.pop
        FV = self.decomposition.do(
            pop[candidates].get("F"), weights=self.ref_dirs[candidates, :], ideal_point=self.ideal
        )
        off_FV = self.decomposition.do(
            off.F[None, :], weights=self.ref_dirs[candidates, :], ideal_point=self.ideal
        )
        I = np.where(off_FV < FV)[0]  # noqa: E741
        pop[candidates[I]] = off


def make_moead_nrd(pop_size: int = 50, **kwargs) -> MOEADNRD:
    from math import comb

    from pymoo.util.ref_dirs import get_reference_directions

    n_obj = 3
    p = 1
    while comb(p + n_obj - 1, n_obj - 1) < pop_size:
        p += 1
    ref_dirs = get_reference_directions("das-dennis", n_obj, n_partitions=p)
    return MOEADNRD(ref_dirs=ref_dirs, n_neighbors=15, prob_neighbor_mating=0.7, **kwargs)
