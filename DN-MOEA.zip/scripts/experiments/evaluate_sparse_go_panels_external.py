"""Evaluate nested sparse-GO panels in the two external cohorts.

Panel membership is fixed before external labels are used. Each external
cohort receives the same stratified five-fold out-of-fold refitting protocol.
This estimates feature-set portability and is not a locked-model validation.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.geo_data import load_gse142025, load_gse30528, load_gse96804  # noqa: E402
from dn_moea.preprocessing import build_candidate_pool  # noqa: E402

OUTER_SEED = 20260920
CONTROL_SEED = 20262000


def oof_metrics(
    expression: pd.DataFrame,
    labels: pd.Series,
    genes: list[str],
    splits: list[tuple[np.ndarray, np.ndarray]],
) -> tuple[float, float, int]:
    available = [gene for gene in genes if gene in expression.index]
    if not available:
        return 0.5, 0.5, 0
    x = expression.loc[available, labels.index].T.to_numpy(dtype=float)
    y = labels.to_numpy(dtype=int)
    probabilities = np.zeros(len(y), dtype=float)
    predictions = np.zeros(len(y), dtype=int)
    for train_idx, test_idx in splits:
        scaler = StandardScaler()
        x_train = scaler.fit_transform(x[train_idx])
        x_test = scaler.transform(x[test_idx])
        model = LogisticRegression(max_iter=2000, C=0.1)
        model.fit(x_train, y[train_idx])
        probabilities[test_idx] = model.predict_proba(x_test)[:, 1]
        predictions[test_idx] = (probabilities[test_idx] >= 0.5).astype(int)
    return (
        float(roc_auc_score(y, probabilities)),
        float(balanced_accuracy_score(y, predictions)),
        len(available),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--n-random", type=int, default=50)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    panels = pd.read_csv(args.input)
    discovery_expr, discovery_labels = load_gse96804()
    gse30528_expr, gse30528_labels = load_gse30528()
    gse142025_expr, gse142025_labels = load_gse142025()
    external = {
        "GSE30528": (gse30528_expr, gse30528_labels),
        "GSE142025": (gse142025_expr, gse142025_labels),
    }
    assay_universe = discovery_expr.index.intersection(gse30528_expr.index)
    outer = RepeatedStratifiedKFold(n_splits=5, n_repeats=4, random_state=OUTER_SEED)
    split_info: dict[int, list[str]] = {}
    for split, (train_idx, _) in enumerate(outer.split(discovery_expr.T, discovery_labels)):
        train_samples = discovery_expr.columns[train_idx]
        train_expr = discovery_expr.loc[:, train_samples]
        train_labels = discovery_labels.loc[train_samples]
        split_info[split] = build_candidate_pool(
            train_expr,
            train_labels,
            assay_universe,
            max_pool_size=2000,
        )

    rows: list[dict] = []
    for record in panels.itertuples(index=False):
        panel = [gene for gene in str(record.genes).split(",") if gene and gene != "nan"]
        pool = split_info[int(record.split)]
        for cohort_index, (cohort, (expression, labels)) in enumerate(external.items()):
            cv = StratifiedKFold(
                n_splits=5,
                shuffle=True,
                random_state=OUTER_SEED + int(record.split),
            )
            cv_splits = list(cv.split(expression.T, labels))
            auc, ba, effective_size = oof_metrics(expression, labels, panel, cv_splits)
            available_pool = [gene for gene in pool if gene in expression.index]
            topdeg = available_pool[:effective_size]
            topdeg_auc, topdeg_ba, _ = oof_metrics(
                expression, labels, topdeg, cv_splits
            )
            rng = np.random.default_rng(
                CONTROL_SEED
                + 100000 * int(record.split)
                + 1000 * effective_size
                + cohort_index
            )
            random_metrics = [
                oof_metrics(
                    expression,
                    labels,
                    rng.choice(
                        available_pool, size=effective_size, replace=False
                    ).tolist(),
                    cv_splits,
                )[:2]
                for _ in range(args.n_random)
            ]
            random_array = np.asarray(random_metrics, dtype=float)
            rows.append(
                {
                    "condition": record.condition,
                    "algorithm": record.algorithm,
                    "split": int(record.split),
                    "cohort": cohort,
                    "original_panel_size": len(panel),
                    "effective_panel_size": effective_size,
                    "genes": ",".join(panel),
                    "auc": auc,
                    "balanced_accuracy": ba,
                    "random_auc_mean": float(random_array[:, 0].mean()),
                    "random_ba_mean": float(random_array[:, 1].mean()),
                    "topdeg_auc": topdeg_auc,
                    "topdeg_ba": topdeg_ba,
                }
            )

    result = pd.DataFrame(rows).sort_values(
        ["cohort", "condition", "algorithm", "split"]
    )
    expected_rows = 2 * len(panels)
    if len(result) != expected_rows:
        raise RuntimeError(f"expected {expected_rows} rows, found {len(result)}")
    result.to_csv(args.output_dir / "external_portability_per_panel.csv", index=False)
    summary = (
        result.assign(
            delta_auc_random=result.auc - result.random_auc_mean,
            delta_ba_random=result.balanced_accuracy - result.random_ba_mean,
            delta_auc_topdeg=result.auc - result.topdeg_auc,
            delta_ba_topdeg=result.balanced_accuracy - result.topdeg_ba,
        )
        .groupby(["cohort", "condition", "algorithm"])
        .agg(
            n_panels=("split", "size"),
            effective_size_mean=("effective_panel_size", "mean"),
            auc_mean=("auc", "mean"),
            auc_sd=("auc", "std"),
            balanced_accuracy_mean=("balanced_accuracy", "mean"),
            balanced_accuracy_sd=("balanced_accuracy", "std"),
            delta_auc_random_mean=("delta_auc_random", "mean"),
            delta_ba_random_mean=("delta_ba_random", "mean"),
            delta_auc_topdeg_mean=("delta_auc_topdeg", "mean"),
            delta_ba_topdeg_mean=("delta_ba_topdeg", "mean"),
        )
        .reset_index()
    )
    summary.to_csv(args.output_dir / "external_portability_summary.csv", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
