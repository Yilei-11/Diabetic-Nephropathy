import numpy as np
import pandas as pd

from dn_moea.experiment import run_experiment
from dn_moea.problem import DNPanelProblem


def _toy_problem():
    rng = np.random.default_rng(1)
    genes = [f"G{i}" for i in range(8)]
    samples = [f"S{i}" for i in range(12)]
    labels = pd.Series([0] * 6 + [1] * 6, index=samples)
    expr = pd.DataFrame(rng.normal(size=(8, 12)), index=genes, columns=samples)
    expr.loc["G0", labels == 1] += 2.0
    return DNPanelProblem(genes, expr, labels)


def test_panel_encoding_and_objective_shape():
    problem = _toy_problem()
    out = {}
    problem._evaluate(np.array([0.6, 0.4] + [0.0] * 6), out)

    assert problem.panel_from_vector(np.array([0.6, 0.4] + [0.0] * 6)) == ["G0"]
    assert np.asarray(out["F"]).shape == (3,)
    assert np.all(np.isfinite(out["F"]))


def test_tiny_end_to_end_experiment():
    result = run_experiment(_toy_problem(), pop_size=8, n_gen=2, seed=1)

    assert result.X.shape[1] == 8
    assert result.F.shape[1] == 3
    assert len(result.panels()) == result.X.shape[0]
