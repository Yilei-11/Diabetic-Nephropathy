"""pymoo problem definition for supervised DN gene-panel selection.

The decision vector is a boolean vector of length ``len(candidate_pool)``;
``True`` at position ``i`` selects ``candidate_pool[i]``. Panel-size
enforcement is done via a repair operator (``sampling.PanelSizeRepair``),
not a pymoo constraint -- see that module's docstring for why (pymoo's stock
MOEAD implementation rejects constrained problems outright, which would make
a fair 6-algorithm comparison impossible).
"""
from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from pymoo.core.problem import ElementwiseProblem

from .objectives import classification_balanced_accuracy, leanness, pathway_relevance


class DNPanelProblem(ElementwiseProblem):
    """Three-objective DN panel-selection problem.

    Pymoo minimizes objectives, so the three maximization-style scientific
    objectives are negated before being returned:

    ``[-leanness, -balanced_accuracy, -pathway_relevance]``.

    ``max_panel_size`` is stored here for informational purposes and is
    expected to be enforced by pairing this problem with
    ``sampling.SparsePanelSampling(max_panel_size)`` (initialization) and
    ``sampling.PanelSizeRepair(max_panel_size)`` (post-variation repair) when
    constructing the algorithm -- see ``experiment.run_experiment``'s
    ``**algo_kwargs``. Without any cap, the first HPC-scale run of this
    project found the search converging on 177-535-gene "panels" (out of a
    ~1226-gene candidate pool) rather than the project's intended 5-10-gene
    diagnostic panel: with only 61 training samples, a logistic regression on
    150+ genes trivially reaches balanced_accuracy=1.0, so the leanness
    objective alone provided far too weak a pressure toward small panels once
    accuracy saturated.
    """

    def __init__(
        self,
        candidate_pool: Sequence[str],
        expression: pd.DataFrame,
        labels: pd.Series,
        *,
        cv_splits: int = 5,
        random_state: int = 0,
        max_panel_size: int = 30,
    ) -> None:
        self.candidate_pool = tuple(candidate_pool)
        if not self.candidate_pool:
            raise ValueError("candidate_pool must contain at least one gene")
        missing = expression.index.difference(self.candidate_pool)
        if len(missing) == len(expression.index):
            raise ValueError("expression does not contain any candidate-pool genes")
        if not expression.columns.equals(labels.index):
            expression = expression.loc[:, labels.index.intersection(expression.columns)]
            labels = labels.loc[expression.columns]
        if expression.columns.empty:
            raise ValueError("expression and labels have no shared samples")

        self.expression = expression
        self.labels = labels
        self.cv_splits = cv_splits
        self.random_state = random_state
        self.max_panel_size = max_panel_size
        super().__init__(
            n_var=len(self.candidate_pool),
            n_obj=3,
            n_ieq_constr=0,
            xl=0.0,
            xu=1.0,
            vtype=bool,
        )

    def panel_from_vector(self, x: np.ndarray) -> list[str]:
        """Convert a decision vector into a deterministic gene list."""
        selected = np.flatnonzero(np.asarray(x) >= 0.5)
        return [self.candidate_pool[i] for i in selected]

    def _evaluate(self, x, out, *args, **kwargs) -> None:
        panel = self.panel_from_vector(x)
        pathway = pathway_relevance(panel, self.candidate_pool)
        accuracy = classification_balanced_accuracy(
            panel,
            self.expression,
            self.labels,
            n_splits=self.cv_splits,
            random_state=self.random_state,
        )
        out["F"] = [-leanness(panel), -accuracy, -pathway]

