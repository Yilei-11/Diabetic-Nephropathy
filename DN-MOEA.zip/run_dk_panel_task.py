"""Run exactly one algorithm/seed task for local or batch scheduling."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
from pymoo.operators.crossover.pntx import TwoPointCrossover
from pymoo.operators.mutation.bitflip import BitflipMutation

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.experiment import run_experiment, save_result  # noqa: E402
from dn_moea.geo_data import load_gse30528, load_gse96804  # noqa: E402
from dn_moea.preprocessing import build_candidate_pool  # noqa: E402
from dn_moea.problem import DNPanelProblem  # noqa: E402
from dn_moea.sampling import PanelSizeRepair, SparsePanelSampling  # noqa: E402
from dn_moea.validation import validate_panels  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithm", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--pop-size", type=int, default=100)
    parser.add_argument("--max-evals", type=int, default=10_000)
    parser.add_argument("--max-pool-size", type=int, default=2_000)
    parser.add_argument("--max-panel-size", type=int, default=30)
    parser.add_argument(
        "--min-panel-size",
        type=int,
        default=0,
        help="Lower bound on panel size (default 0, no lower bound). A positive "
        "value restricts the search to larger panels.",
    )
    parser.add_argument("--output-dir", type=Path, default=Path("results/panel_search"))
    parser.add_argument(
        "--swap-datasets",
        action="store_true",
        help="Use GSE30528 as the training/search set and GSE96804 as external "
        "validation (reversed roles; robustness check).",
    )
    args = parser.parse_args()

    if args.swap_datasets:
        train_expr, train_labels = load_gse30528()
        external_expr, external_labels = load_gse96804()
    else:
        train_expr, train_labels = load_gse96804()
        external_expr, external_labels = load_gse30528()
    pool = build_candidate_pool(
        train_expr,
        train_labels,
        train_expr.index.intersection(external_expr.index),
        max_pool_size=args.max_pool_size,
    )
    problem = DNPanelProblem(
        pool,
        train_expr,
        train_labels,
        random_state=args.seed,
        max_panel_size=args.max_panel_size,
    )
    result = run_experiment(
        problem,
        args.algorithm,
        pop_size=args.pop_size,
        max_evals=args.max_evals,
        seed=args.seed,
        sampling=SparsePanelSampling(args.max_panel_size, min_size=args.min_panel_size),
        crossover=TwoPointCrossover(),
        mutation=BitflipMutation(),
        repair=PanelSizeRepair(args.max_panel_size, min_size=args.min_panel_size),
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{args.algorithm}__seed{args.seed}"
    save_result(result, args.output_dir / f"{stem}.npz")
    report = validate_panels(
        result.panels(), train_expr, train_labels, external_expr, external_labels
    )
    report.insert(0, "algorithm", args.algorithm)
    report.insert(1, "seed", args.seed)
    report.insert(2, "candidate_pool_size", len(pool))
    report.to_csv(args.output_dir / f"{stem}__external_validation.csv", index=False)
    print(f"completed {stem}: evaluations<= {args.max_evals}, pareto={len(result.X)}")


if __name__ == "__main__":
    main()

