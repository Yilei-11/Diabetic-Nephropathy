import numpy as np

from dn_moea.metrics import hypervolume, summarize_runs


def test_hypervolume_uses_shared_reference_point():
    F = np.array([[0.2, 0.8], [0.8, 0.2]])
    assert hypervolume(F, ref_point=[1.0, 1.0]) > 0.0


def test_summarize_runs_groups_algorithms():
    F = np.array([[0.2, 0.8], [0.8, 0.2]])
    summary = summarize_runs(
        [("a", 0, F), ("a", 1, F), ("b", 0, F * 1.1)],
        ref_point=[2.0, 2.0],
    )
    assert set(summary.algorithm) == {"a", "b"}
    assert list(summary.columns) == ["algorithm", "mean", "std", "n"]
    assert summary.loc[summary.algorithm == "a", "n"].iloc[0] == 2

