import numpy as np
import pandas as pd

from dn_moea.validation import external_balanced_accuracy, validate_panels


def test_external_validation_fits_on_train_and_scores_external():
    genes = ["G0", "G1"]
    train = pd.DataFrame(
        [[0, 0, 1, 1], [1, 1, 1, 1]],
        index=genes,
        columns=["T0", "T1", "T2", "T3"],
        dtype=float,
    )
    train_labels = pd.Series([0, 0, 1, 1], index=train.columns)
    external = pd.DataFrame(
        [[0, 1, 0, 1], [1, 1, 1, 1]],
        index=genes,
        columns=["E0", "E1", "E2", "E3"],
        dtype=float,
    )
    external_labels = pd.Series([0, 1, 0, 1], index=external.columns)

    score = external_balanced_accuracy(["G0"], train, train_labels, external, external_labels)
    assert np.isfinite(score)
    assert score >= 0.5

    report = validate_panels([["G0"], ["missing"]], train, train_labels, external, external_labels)
    assert list(report["panel_size"]) == [1, 1]
    assert report.shape == (2, 5)
    assert report.iloc[1].external_balanced_accuracy == 0.5
    assert report.iloc[1].external_auc == 0.5

