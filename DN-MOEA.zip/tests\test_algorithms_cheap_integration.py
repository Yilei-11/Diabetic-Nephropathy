"""Fast sanity runs of every registered algorithm against a cheap built-in
pymoo benchmark problem: catches wiring bugs in a new algorithm (wrong
attribute name, shape mismatch, etc.) in well under a second per algorithm,
without needing real gene-expression data.
"""
import numpy as np
import pytest
from pymoo.optimize import minimize
from pymoo.problems import get_problem

from dn_moea.algorithms.factory import ALGORITHM_NAMES, get_algorithm


@pytest.mark.parametrize("name", ALGORITHM_NAMES)
def test_algorithm_runs_on_cheap_3obj_problem(name):
    problem = get_problem("dtlz2", n_var=7, n_obj=3)
    algorithm = get_algorithm(name, pop_size=20)

    res = minimize(problem, algorithm, termination=("n_gen", 5), seed=1, verbose=False)

    assert res.F is not None
    F = np.atleast_2d(res.F)
    assert F.shape[1] == 3
    assert F.shape[0] >= 1
    assert np.all(np.isfinite(F))
