"""Metrics for comparing saved multi-objective DN panel runs."""
from __future__ import annotations

from collections.abc import Iterable, Sequence

import numpy as np
import pandas as pd
from pymoo.indicators.hv import HV


def hypervolume(F: np.ndarray, ref_point: Sequence[float] | None = None) -> float:
    """Compute minimization hypervolume for a finite objective matrix.

    Use the same explicit ``ref_point`` for every algorithm when comparing
    runs.  If omitted, a convenient run-local reference is derived and should
    not be used for cross-run scientific comparisons.
    """
    values = np.atleast_2d(np.asarray(F, dtype=float))
    values = values[np.all(np.isfinite(values), axis=1)]
    if values.size == 0:
        return 0.0
    if ref_point is None:
        ref = values.max(axis=0) + 0.1
    else:
        ref = np.asarray(ref_point, dtype=float)
    if ref.shape != (values.shape[1],) or np.any(ref <= values.max(axis=0)):
        raise ValueError("ref_point must have one worse coordinate per objective")
    return float(HV(ref_point=ref).do(values))


def summarize_runs(
    runs: Iterable[tuple[str, int, np.ndarray]],
    ref_point: Sequence[float],
) -> pd.DataFrame:
    """Summarize hypervolume by algorithm and seed."""
    rows = [
        {"algorithm": algorithm, "seed": seed, "hypervolume": hypervolume(F, ref_point)}
        for algorithm, seed, F in runs
    ]
    per_run = pd.DataFrame(rows)
    if per_run.empty:
        return pd.DataFrame(columns=["algorithm", "mean", "std", "n"])
    return (
        per_run.groupby("algorithm")["hypervolume"]
        .agg(mean="mean", std="std", n="count")
        .reset_index()
    )

