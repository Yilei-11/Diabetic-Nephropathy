"""Independent validation of gene panels on the held-out GEO dataset."""
from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.preprocessing import StandardScaler


def _youden_threshold(y_true: np.ndarray, proba: np.ndarray) -> float:
    """Decision threshold maximizing Youden's J (TPR - FPR) on the training
    labels. Used instead of a fixed 0.5 cut-off because the case proportion
    differs between the training and the external cohort (67% in GSE96804,
    41% in GSE30528). Only training labels are used."""
    fpr, tpr, thresholds = roc_curve(y_true, proba)
    return float(thresholds[np.argmax(tpr - fpr)])


def external_balanced_accuracy(
    panel: Sequence[str],
    train_expression: pd.DataFrame,
    train_labels: pd.Series,
    external_expression: pd.DataFrame,
    external_labels: pd.Series,
) -> float:
    """Train on one dataset and score the unchanged panel's classifier
    coefficients on another, cross-platform cohort.

    GSE96804 and GSE30528 are on different scales: log2 exon-array signal
    versus a per-probe-centered array export. A scaler fitted on GSE96804
    and applied to GSE30528 would map external samples to extreme z-scores.
    Each cohort is therefore standardized against its own mean and SD before
    the coefficients learned on the training cohort are applied, so that the
    decision boundary transfers in standardized space. Genes absent from
    either dataset are ignored; if no
    selected genes remain, chance performance is returned.
    """
    genes = [
        gene
        for gene in panel
        if gene in train_expression.index and gene in external_expression.index
    ]
    if not genes:
        return 0.5

    train_columns = train_expression.columns.intersection(train_labels.index)
    external_columns = external_expression.columns.intersection(external_labels.index)
    if train_columns.empty or external_columns.empty:
        return 0.5

    X_train = train_expression.loc[genes, train_columns].T.to_numpy()
    y_train = train_labels.loc[train_columns].to_numpy()
    X_external = external_expression.loc[genes, external_columns].T.to_numpy()
    y_external = external_labels.loc[external_columns].to_numpy()
    if len(np.unique(y_train)) < 2 or len(np.unique(y_external)) < 2:
        return 0.5

    # Standardize each cohort against its OWN mean/SD -- not a shared scaler --
    # so cross-platform transfer compares standardized expression shape rather
    # than incompatible absolute scales. See docstring above.
    X_train = StandardScaler().fit_transform(X_train)
    X_external = StandardScaler().fit_transform(X_external)
    clf = LogisticRegression(max_iter=1000, C=0.1)
    clf.fit(X_train, y_train)
    threshold = _youden_threshold(y_train, clf.predict_proba(X_train)[:, 1])
    predictions = (clf.predict_proba(X_external)[:, 1] >= threshold).astype(int)
    recalls = [
        float((predictions[y_external == cls] == cls).mean())
        for cls in (0, 1)
        if np.any(y_external == cls)
    ]
    return float(np.mean(recalls)) if recalls else 0.5


def external_auc(
    panel: Sequence[str],
    train_expression: pd.DataFrame,
    train_labels: pd.Series,
    external_expression: pd.DataFrame,
    external_labels: pd.Series,
) -> float:
    """Same direct cross-platform transfer as :func:`external_balanced_accuracy`
    (per-cohort standardization, coefficients learned on the training cohort
    applied unchanged to the external cohort), scored by ROC-AUC instead of
    balanced accuracy. Chance-level 0.5 is returned wherever balanced accuracy
    would also fall back to it (missing genes, empty cohorts, single-class
    labels)."""
    genes = [
        gene
        for gene in panel
        if gene in train_expression.index and gene in external_expression.index
    ]
    if not genes:
        return 0.5

    train_columns = train_expression.columns.intersection(train_labels.index)
    external_columns = external_expression.columns.intersection(external_labels.index)
    if train_columns.empty or external_columns.empty:
        return 0.5

    X_train = train_expression.loc[genes, train_columns].T.to_numpy()
    y_train = train_labels.loc[train_columns].to_numpy()
    X_external = external_expression.loc[genes, external_columns].T.to_numpy()
    y_external = external_labels.loc[external_columns].to_numpy()
    if len(np.unique(y_train)) < 2 or len(np.unique(y_external)) < 2:
        return 0.5

    X_train = StandardScaler().fit_transform(X_train)
    X_external = StandardScaler().fit_transform(X_external)
    clf = LogisticRegression(max_iter=1000, C=0.1)
    clf.fit(X_train, y_train)
    scores = clf.predict_proba(X_external)[:, 1]
    return float(roc_auc_score(y_external, scores))


def validate_panels(
    panels: Sequence[Sequence[str]],
    train_expression: pd.DataFrame,
    train_labels: pd.Series,
    external_expression: pd.DataFrame,
    external_labels: pd.Series,
) -> pd.DataFrame:
    """Return one external-validation record per Panel."""
    rows = []
    for index, panel in enumerate(panels):
        rows.append(
            {
                "panel_index": index,
                "panel_size": len(panel),
                "genes": ",".join(panel),
                "external_balanced_accuracy": external_balanced_accuracy(
                    panel,
                    train_expression,
                    train_labels,
                    external_expression,
                    external_labels,
                ),
                "external_auc": external_auc(
                    panel,
                    train_expression,
                    train_labels,
                    external_expression,
                    external_labels,
                ),
            }
        )
    return pd.DataFrame(rows)


def external_retrained_balanced_accuracy(
    panel: Sequence[str],
    external_expression: pd.DataFrame,
    external_labels: pd.Series,
    *,
    n_splits: int = 5,
    random_state: int = 0,
) -> float:
    """Evaluate a fixed Panel by retraining within the external platform.

    This measures whether the genes selected in the primary dataset retain
    diagnostic signal when a classifier is refit using the external dataset's
    own expression scale.  The Panel itself is never selected using external
    labels.  It is distinct from :func:`external_balanced_accuracy`, which
    transfers a classifier fitted on the primary platform directly across
    platforms and is highly sensitive to platform-scale shifts.
    """
    genes = [gene for gene in panel if gene in external_expression.index]
    columns = external_expression.columns.intersection(external_labels.index)
    if not genes or columns.empty:
        return 0.5
    y = external_labels.loc[columns].to_numpy()
    n_splits = min(n_splits, int(np.bincount(y).min()))
    if n_splits < 2:
        return 0.5
    X = external_expression.loc[genes, columns].T.to_numpy()
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    scores = []
    for train_idx, test_idx in cv.split(X, y):
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X[train_idx])
        X_test = scaler.transform(X[test_idx])
        clf = LogisticRegression(max_iter=1000, C=0.1)
        clf.fit(X_train, y[train_idx])
        pred = clf.predict(X_test)
        recalls = [
            float((pred[y[test_idx] == cls] == cls).mean())
            for cls in (0, 1)
            if np.any(y[test_idx] == cls)
        ]
        scores.append(float(np.mean(recalls)))
    return float(np.mean(scores))


def external_retrained_auc(
    panel: Sequence[str],
    external_expression: pd.DataFrame,
    external_labels: pd.Series,
    *,
    n_splits: int = 5,
    random_state: int = 0,
) -> float:
    """Evaluate a fixed panel by external-cohort retraining using ROC-AUC."""
    genes = [gene for gene in panel if gene in external_expression.index]
    columns = external_expression.columns.intersection(external_labels.index)
    if not genes or columns.empty:
        return 0.5
    y = external_labels.loc[columns].to_numpy()
    n_splits = min(n_splits, int(np.bincount(y).min()))
    if n_splits < 2:
        return 0.5
    X = external_expression.loc[genes, columns].T.to_numpy()
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    scores = []
    for train_idx, test_idx in cv.split(X, y):
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X[train_idx])
        X_test = scaler.transform(X[test_idx])
        clf = LogisticRegression(max_iter=1000, C=0.1)
        clf.fit(X_train, y[train_idx])
        scores.append(float(roc_auc_score(y[test_idx], clf.predict_proba(X_test)[:, 1])))
    return float(np.mean(scores))
