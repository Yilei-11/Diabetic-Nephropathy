"""Supplementary Figure S1: cumulative outer repeats and permuted-label null."""
import sys
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import figstyle  # noqa: E402

figstyle.apply(8.5)
REV = Path(__file__).resolve().parents[2]
AGG = REV / "results/aggregate"
NAME = {"nsga2": "NSGA-II", "nsga2_tiebreak": "NSGA-II tie-break", "spea2": "SPEA2",
        "spea2_plus": "SPEA2+", "moead": "MOEA/D", "moead_nrd": "MOEA/D-NRD"}
COL = ["#1b4f8a", "#4f8fc6", "#b5651d", "#e3a35b", "#3d7a3d", "#8cc084"]
rep = pd.read_csv(AGG / "repeats_cumulative.csv")
perm = pd.read_csv(AGG / "perm_per_permutation.csv")
obs = pd.read_csv(AGG / "perm_summary.csv", index_col=0).iloc[:, 0]

fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), gridspec_kw={"width_ratios": [1, 1, 0.9]})
for (alg, name), c in zip(NAME.items(), COL):
    g = rep[rep.algorithm == alg]
    axes[0].plot(g.n_repeats, g.auc_mean, marker="o", ms=2.5, lw=1, color=c, label=name)
    axes[1].plot(g.n_repeats, g.delta_topdeg, marker="o", ms=2.5, lw=1, color=c)
axes[0].set_ylim(0.95, 1.0)
axes[0].set_xlabel("Outer repeats included")
axes[0].set_ylabel("Mean outer AUC")
axes[0].legend(frameon=False, fontsize=6.3, loc="lower right")
axes[1].axhline(0, color="gray", lw=0.7, ls="--")
axes[1].set_xlabel("Outer repeats included")
axes[1].set_ylabel("$\\Delta$AUC versus top-DEG")
axes[2].hist(perm.outer_auc, bins=10, range=(0.2, 1.0), color="#9e9e9e", edgecolor="white")
axes[2].axvline(obs["observed_repeat0_auc"], color="#c0392b", lw=1.4)
axes[2].text(obs["observed_repeat0_auc"] - 0.02, axes[2].get_ylim()[1] * 0.9, "Real labels", ha="right", fontsize=7, color="#c0392b")
axes[2].set_xlabel("Mean outer AUC, five folds")
axes[2].set_ylabel("Permutations")
for ax, lab in zip(axes, "abc"):
    ax.text(-0.28, 1.04, f"({lab})", transform=ax.transAxes, fontsize=10, weight="bold")
    ax.spines[["top", "right"]].set_visible(False)
for ax in axes[:2]:
    ax.set_xticks(range(1, 11))
fig.tight_layout()
out = Path(sys.argv[1])
fig.savefig(out)
fig.savefig(out.with_suffix(".png"), dpi=200)
