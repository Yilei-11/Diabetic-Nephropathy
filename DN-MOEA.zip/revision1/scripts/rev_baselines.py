"""Established feature-selection baselines under the identical nested outer splits.

Every method sees only the outer training split and the same split-specific
DEG candidate pool as the evolutionary search. Selected gene sets are scored
with the common evaluation classifier (standardized L2 logistic regression,
C=0.1) on the held-out outer fold, exactly as the evolutionary panels.

Methods: LASSO and elastic-net logistic regression tuned by inner 5-fold CV,
recursive feature elimination to the NSGA-II panel size of the same split,
RFE with cross-validated size (RFECV), and stability selection.
"""
from __future__ import annotations

import argparse
import sys
import warnings
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import RFE, RFECV
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from dn_moea.preprocessing import build_candidate_pool  # noqa: E402
from rev_task import SEARCH_SEED, load_cached, outer_splits  # noqa: E402
from scripts.experiments.run_nested_ablation_study import evaluate_outer  # noqa: E402

warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

CS = np.logspace(-2, 2, 20)


def nonzero(coef: np.ndarray, pool: list[str]) -> list[str]:
    idx = np.flatnonzero(np.abs(coef.ravel()) > 1e-8)
    if len(idx) == 0:
        idx = [int(np.argmax(np.abs(coef.ravel())))]
    return [pool[i] for i in idx]


def run_split(args: tuple[int, int]) -> list[dict]:
    split, ec_size = args
    expression, labels, external_expression, _ = load_cached()
    universe = expression.index.intersection(external_expression.index)
    n_repeats = max(4, split // 5 + 1)
    train_idx, test_idx = outer_splits(expression, labels, n_repeats)[split]
    tr, te = expression.columns[train_idx], expression.columns[test_idx]
    train_expr, test_expr = expression.loc[:, tr], expression.loc[:, te]
    y_tr, y_te = labels.loc[tr], labels.loc[te]
    pool = build_candidate_pool(train_expr, y_tr, universe, max_pool_size=2000)
    X = StandardScaler().fit_transform(train_expr.loc[pool, tr].T.to_numpy(dtype=float))
    y = y_tr.to_numpy()
    seed = SEARCH_SEED + split
    inner = StratifiedKFold(5, shuffle=True, random_state=seed)
    panels: dict[str, list[str]] = {}

    lasso = LogisticRegressionCV(
        Cs=CS, cv=inner, penalty="l1", solver="liblinear", scoring="roc_auc", max_iter=5000, random_state=seed
    ).fit(X, y)
    panels["lasso"] = nonzero(lasso.coef_, pool)
    c_lasso = float(lasso.C_[0])

    enet = LogisticRegressionCV(
        Cs=10, cv=inner, penalty="elasticnet", solver="saga", l1_ratios=[0.1, 0.5, 0.9],
        scoring="roc_auc", max_iter=5000, random_state=seed,
    ).fit(X, y)
    panels["elastic_net"] = nonzero(enet.coef_, pool)

    base = LogisticRegression(C=0.1, max_iter=2000)
    rfe = RFE(base, n_features_to_select=int(ec_size), step=0.1).fit(X, y)
    panels["rfe_matched"] = [g for g, s in zip(pool, rfe.support_) if s]
    rfecv = RFECV(base, step=0.1, cv=inner, scoring="balanced_accuracy", min_features_to_select=1).fit(X, y)
    panels["rfecv"] = [g for g, s in zip(pool, rfecv.support_) if s]

    # Stability selection (Meinshausen & Buhlmann 2010): 100 stratified half
    # subsamples; L1 logistic regression over a grid of penalties; a gene is
    # kept when its maximum selection probability over the grid is >= 0.6.
    grid = [0.05, 0.1, 0.2, 0.5, 1.0]
    counts = np.zeros((len(grid), len(pool)))
    sss = StratifiedShuffleSplit(n_splits=100, train_size=0.5, random_state=seed)
    for sub, _ in sss.split(X, y):
        for gi, c in enumerate(grid):
            model = LogisticRegression(penalty="l1", solver="liblinear", C=c, max_iter=5000, random_state=seed)
            model.fit(X[sub], y[sub])
            counts[gi] += np.abs(model.coef_.ravel()) > 1e-8
    freq = (counts / 100).max(axis=0)
    keep = np.flatnonzero(freq >= 0.6)
    if len(keep) == 0:
        keep = [int(np.argmax(freq))]
    panels["stability_selection"] = [pool[i] for i in keep]

    rows = []
    for method, genes in panels.items():
        auc, ba = evaluate_outer(genes, train_expr, y_tr, test_expr, y_te)
        rows.append(
            dict(
                method=method, split=split, repeat=split // 5, fold=split % 5,
                candidate_pool_size=len(pool), panel_size=len(genes), genes=",".join(genes),
                outer_auc=auc, outer_balanced_accuracy=ba,
                lasso_C=c_lasso,
                enet_C=float(enet.C_[0]), enet_l1_ratio=float(enet.l1_ratio_[0]),
                stability_max_freq=float(freq.max()),
            )
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--per-split", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=10)
    args = parser.parse_args()
    per_split = pd.read_csv(args.per_split)
    ec = per_split[(per_split.algorithm == "nsga2") & (per_split.condition == "go_real")]
    tasks = [(int(r.split), int(r.panel_size)) for r in ec.itertuples()]
    with ProcessPoolExecutor(args.workers) as ex:
        rows = [row for out in ex.map(run_split, tasks) for row in out]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).sort_values(["method", "split"]).to_csv(args.output, index=False)
    print(pd.DataFrame(rows).groupby("method")[["panel_size", "outer_auc", "outer_balanced_accuracy"]].mean())


if __name__ == "__main__":
    main()
