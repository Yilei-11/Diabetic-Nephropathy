"""Over-representation of selected genes in Reactome, KEGG and Hallmark for
panels from different search conditions (sensitivity to the GO objective)."""
import sys
from pathlib import Path
import pandas as pd
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests
sys.path.insert(0, str(Path(__file__).resolve().parent))
from rev_go_rule_annotation import LIBS, genes_of, read_gmt

REV = Path(__file__).resolve().parents[1]
per = pd.read_csv(REV.parent / "results/sparse_go_pairwise_final_20260920/per_split.csv")
pools = pd.read_pickle(REV / "results/uncertainty/pools_20splits.pkl")
seeds = pd.read_csv(REV / "results/aggregate/seeds_per_run.csv")
bg = set().union(*[set(p) for p in pools.values()])
libs = {k: read_gmt(v) for k, v in LIBS.items()}
queries = {
    "real_go_representatives_all_algorithms": [g for s in per[per.condition == "go_real"].genes for g in genes_of(s)],
    "no_go_nsga2": [g for s in per[per.condition == "no_go"].genes for g in genes_of(s)],
    "randomized_go_nsga2": [g for s in per[per.condition == "go_randomized"].genes for g in genes_of(s)],
}
c = pd.Series([g for s in seeds.genes for g in genes_of(s)]).value_counts()
queries["five_runs_all_algorithms_count_ge3"] = list(c[c >= 3].index)
rows = []
for label, q in queries.items():
    q = set(q) & bg
    for lib, sets in libs.items():
        part = []
        for term, members in sets:
            m = members & bg
            if len(m) < 3:
                continue
            h = q & m
            p = hypergeom.sf(len(h) - 1, len(bg), len(m), len(q)) if h else 1.0
            part.append(dict(query=label, library=lib, term=term, n_query=len(q), n_term=len(m),
                             n_background=len(bg), overlap=len(h), p=p, genes=",".join(sorted(h))))
        part = pd.DataFrame(part)
        part["fdr"] = multipletests(part.p, method="fdr_bh")[1]
        rows.append(part)
out = pd.concat(rows).sort_values(["query", "fdr", "p"])
out.to_csv(REV / "results/go_rule_annotation/enrichment_by_condition.csv", index=False)
c.rename("runs_selected_of_600").to_csv(REV / "results/go_rule_annotation/gene_counts_600_runs.csv")
print(out[out.fdr < 0.05].groupby("query").head(6)[["query", "library", "term", "overlap", "n_term", "fdr"]].to_string(index=False))
