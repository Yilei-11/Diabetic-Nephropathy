"""GO-aware representative rule and annotation sources not used in optimization.

1. Tolerance rule: within each final archive, keep panels whose inner-CV
   balanced accuracy is within delta of the archive maximum and choose the
   panel with the largest real-GO coherence (ties: smaller panel, then higher
   inner accuracy).  delta = 0.025 and 0.05.  The chosen panel is refitted on
   the outer training split and scored once on the outer test fold.
2. Independent annotation: pairwise Jaccard coherence computed from Reactome
   2022, KEGG 2021 Human and MSigDB Hallmark 2020 memberships (same term
   filters as the GO objective) for representative, tolerance-rule and
   archive-maximum panels, with a same-size random-panel expectation.
3. Over-representation of recurrently selected genes in the same three
   libraries against the union of candidate pools (hypergeometric, BH).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.stats import hypergeom
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]
REV = ROOT / "revision1"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from rev_task import load_cached, outer_splits  # noqa: E402
from scripts.experiments.run_nested_ablation_study import evaluate_outer  # noqa: E402

LIBS = {"Reactome": "Reactome_2022", "KEGG": "KEGG_2021_Human", "Hallmark": "MSigDB_Hallmark_2020"}
DELTAS = (0.025, 0.05)


def read_gmt(name: str) -> list[tuple[str, frozenset]]:
    out = []
    for line in (REV / "genesets" / f"{name}.gmt").read_text().splitlines():
        f = line.split("\t")
        if len(f) >= 3:
            out.append((f[0], frozenset(g for g in f[2:] if g)))
    return out


class Coherence:
    def __init__(self, pool, sets, min_size=3, max_frac=0.5):
        self.index = {g: i for i, g in enumerate(pool)}
        n = len(pool)
        rows, cols, t = [], [], 0
        pool_set = set(pool)
        max_size = max(min_size, int(np.floor(max_frac * n)))
        for _, members in sets:
            m = members & pool_set
            if min_size <= len(m) <= max_size:
                rows += [self.index[g] for g in m]
                cols += [t] * len(m)
                t += 1
        if t == 0:
            self.sim = np.zeros((n, n), dtype=np.float32)
            return
        M = sparse.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)), shape=(n, t))
        inter = (M @ M.T).toarray()
        deg = np.asarray(M.sum(axis=1)).ravel()
        union = deg[:, None] + deg[None, :] - inter
        sim = np.divide(inter, union, out=np.zeros_like(inter), where=union > 0)
        np.fill_diagonal(sim, 0)
        self.sim = sim.astype(np.float32)

    def score(self, genes) -> float:
        idx = np.array([self.index[g] for g in dict.fromkeys(genes) if g in self.index], int)
        k = len(idx)
        return 0.0 if k < 2 else float(self.sim[np.ix_(idx, idx)].sum() / (k * (k - 1)))

    def random_mean(self, k: int, rng, n=200) -> float:
        n_genes = self.sim.shape[0]
        if k < 2:
            return 0.0
        vals = []
        for _ in range(n):
            idx = rng.choice(n_genes, k, replace=False)
            vals.append(self.sim[np.ix_(idx, idx)].sum() / (k * (k - 1)))
        return float(np.mean(vals))


def genes_of(s) -> list[str]:
    return [g for g in str(s).split(",") if g and g != "nan"]


def main() -> None:
    out_dir = REV / "results" / "go_rule_annotation"
    out_dir.mkdir(parents=True, exist_ok=True)
    final = ROOT / "results" / "sparse_go_pairwise_final_20260920"
    archives = pd.read_csv(final / "pareto_archives.csv")
    pools = pd.read_pickle(REV / "results" / "uncertainty" / "pools_20splits.pkl")
    expression, labels, _, _ = load_cached()
    splits = outer_splits(expression, labels, 4)
    libs = {k: read_gmt(v) for k, v in LIBS.items()}
    rng = np.random.default_rng(20265000)

    rows = []
    for (cond, alg, split), arc in archives.groupby(["condition", "algorithm", "split"]):
        pool = pools[int(split)]
        scorers = {k: Coherence(pool, v) for k, v in libs.items()}
        tr, te = (expression.columns[i] for i in splits[int(split)])
        args = (expression.loc[:, tr], labels.loc[tr], expression.loc[:, te], labels.loc[te])
        arc = arc.reset_index(drop=True)
        chosen = {"accuracy_first": arc.index[arc.representative.astype(bool)][0]}
        best = arc.inner_balanced_accuracy.max()
        for d in DELTAS:
            cand = arc[arc.inner_balanced_accuracy >= best - d - 1e-12]
            pick = cand.sort_values(
                ["real_go_score", "panel_size", "inner_balanced_accuracy"],
                ascending=[False, True, False],
            ).index[0]
            chosen[f"tolerance_{d}"] = pick
        chosen["archive_max_go"] = arc.real_go_score.idxmax()
        for rule, i in chosen.items():
            genes = genes_of(arc.loc[i, "genes"])
            auc, ba = evaluate_outer(genes, *args)
            row = dict(condition=cond, algorithm=alg, split=int(split), rule=rule,
                       panel_size=len(genes), genes=",".join(genes),
                       inner_balanced_accuracy=float(arc.loc[i, "inner_balanced_accuracy"]),
                       real_go=float(arc.loc[i, "real_go_score"]), outer_auc=auc, outer_ba=ba)
            for k, sc in scorers.items():
                row[f"{k}_coherence"] = sc.score(genes)
                row[f"{k}_random"] = sc.random_mean(len(genes), rng)
            rows.append(row)
        # archive-level maximum of each independent coherence
        for k, sc in scorers.items():
            vals = [sc.score(genes_of(g)) for g in arc.genes]
            rows.append(dict(condition=cond, algorithm=alg, split=int(split),
                             rule=f"archive_max_{k}", **{f"{k}_coherence": float(np.max(vals))}))
        print(cond, alg, split, flush=True)
    per = pd.DataFrame(rows)
    per.to_csv(out_dir / "per_split_rules.csv", index=False)

    # Over-representation of recurrent genes (real-GO representatives, all algorithms)
    rep = archives[(archives.condition == "go_real") & archives.representative.astype(bool)]
    counts = pd.Series([g for s in rep.genes for g in genes_of(s)]).value_counts()
    background = sorted(set().union(*[set(p) for p in pools.values()]))
    enr = []
    for min_count in (1, 2):
        query = set(counts[counts >= min_count].index) & set(background)
        for lib, sets in libs.items():
            for term, members in sets:
                m = members & set(background)
                if len(m) < 3:
                    continue
                hit = query & m
                p = hypergeom.sf(len(hit) - 1, len(background), len(m), len(query)) if hit else 1.0
                enr.append(dict(min_count=min_count, library=lib, term=term, n_query=len(query),
                                n_term=len(m), n_background=len(background), overlap=len(hit),
                                genes=",".join(sorted(hit)), p=p))
    enr = pd.DataFrame(enr)
    enr["fdr"] = np.nan
    for key, g in enr.groupby(["min_count", "library"]):
        enr.loc[g.index, "fdr"] = multipletests(g.p, method="fdr_bh")[1]
    enr.sort_values(["min_count", "fdr", "p"]).to_csv(out_dir / "recurrent_gene_enrichment.csv", index=False)
    counts.rename("count").to_csv(out_dir / "recurrent_gene_counts.csv")


if __name__ == "__main__":
    main()
