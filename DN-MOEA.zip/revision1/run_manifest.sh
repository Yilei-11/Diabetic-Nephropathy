#!/bin/bash
# Run all tasks of a manifest in parallel on one machine.
# Usage: bash revision1/run_manifest.sh revision1/revision_main.csv revision1/results/main [n_parallel]
set -euo pipefail
MANIFEST=$1
OUTDIR=$2
NPAR=${3:-8}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
N=$(($(wc -l < "$MANIFEST") - 1))
seq 0 $((N-1)) | xargs -P "$NPAR" -I{} python revision1/scripts/rev_task.py --manifest "$MANIFEST" --index {} --output-dir "$OUTDIR"
