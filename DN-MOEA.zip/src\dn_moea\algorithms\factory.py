"""Central registry mapping an algorithm name to a configured pymoo instance.

Six algorithms span three mechanism families, each with a classic baseline
and a 2024+ theoretically-motivated variant:

    family            classic     2024+ variant
    ----------------  ----------  --------------------------------
    dominance+crowd.  NSGA-II     NSGA-II + balanced tie-break (AAAI'25)
    strength+archive  SPEA2       SPEA2+ (PPSN'26)
    decomposition     MOEA/D      MOEA/D-NRD (Biomimetics 2025)

All six are implemented and registered below. The three 2024+ variants are
domain-agnostic pymoo extensions (no dependency on this project's
gene-expression data or objectives), each verified line-by-line against its
source paper; see the docstring of the corresponding module in this package
(`moead_nrd.py`, `nsga2_tiebreak.py`, `spea2_plus.py`) for its exact
mechanistic description.
"""
from __future__ import annotations

from pymoo.algorithms.moo.moead import MOEAD
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.spea2 import SPEA2
from pymoo.util.ref_dirs import get_reference_directions

from .moead_nrd import make_moead_nrd
from .nsga2_tiebreak import make_nsga2_tiebreak
from .spea2_plus import make_spea2_plus

ALGORITHM_NAMES = [
    "nsga2",
    "nsga2_tiebreak",
    "spea2",
    "spea2_plus",
    "moead",
    "moead_nrd",
]


def get_algorithm(name: str, pop_size: int = 50, **kwargs):
    """Return a freshly configured pymoo algorithm instance by name.

    ``**kwargs`` (e.g. ``sampling=``/``crossover=``/``mutation=``) are
    forwarded to every algorithm's constructor uniformly, so a caller with a
    non-default encoding (e.g. binary gene selection) can configure all six
    algorithms identically for a fair comparison.
    """
    if name == "nsga2":
        return NSGA2(pop_size=pop_size, **kwargs)

    if name == "nsga2_tiebreak":
        return make_nsga2_tiebreak(pop_size=pop_size, **kwargs)

    if name == "spea2":
        return SPEA2(pop_size=pop_size, **kwargs)

    if name == "spea2_plus":
        return make_spea2_plus(pop_size=pop_size, **kwargs)

    if name == "moead":
        # 3 objectives -> das-dennis partitions chosen so ref_dirs count is
        # close to pop_size (each reference direction = one MOEA/D subproblem)
        n_partitions = _partitions_for_target_size(pop_size, n_obj=3)
        ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=n_partitions)
        return MOEAD(ref_dirs=ref_dirs, n_neighbors=15, prob_neighbor_mating=0.7, **kwargs)

    if name == "moead_nrd":
        return make_moead_nrd(pop_size=pop_size, **kwargs)

    raise ValueError(f"Unknown algorithm name: {name!r}. Known: {ALGORITHM_NAMES}")


def _partitions_for_target_size(target: int, n_obj: int) -> int:
    """Smallest das-dennis partition count p such that C(p+n_obj-1, n_obj-1) >= target."""
    from math import comb

    p = 1
    while comb(p + n_obj - 1, n_obj - 1) < target:
        p += 1
    return p
