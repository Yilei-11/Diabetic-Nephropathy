"""Small, explicit experiment runner for the current DN panel project."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from pymoo.optimize import minimize

from .algorithms.factory import get_algorithm
from .problem import DNPanelProblem


@dataclass(frozen=True)
class ExperimentResult:
    """Saved scientific outputs from one optimization run."""

    algorithm: str
    seed: int
    candidate_pool: tuple[str, ...]
    X: np.ndarray
    F: np.ndarray

    def panels(self, threshold: float = 0.5) -> list[list[str]]:
        return [
            [gene for gene, value in zip(self.candidate_pool, row) if value >= threshold]
            for row in self.X
        ]


def run_experiment(
    problem: DNPanelProblem,
    algorithm_name: str = "nsga2",
    *,
    pop_size: int = 50,
    n_gen: int = 100,
    max_evals: int | None = None,
    seed: int = 0,
    verbose: bool = False,
    **algo_kwargs,
) -> ExperimentResult:
    """Run one reproducible optimization and return its Pareto solutions.

    ``**algo_kwargs`` (e.g. ``sampling=SparsePanelSampling(...)``,
    ``crossover=TwoPointCrossover()``, ``mutation=BitflipMutation()``) are
    forwarded to :func:`get_algorithm` so every one of the six algorithms can
    be configured with the same, problem-appropriate operators.
    """
    algorithm = get_algorithm(algorithm_name, pop_size=pop_size, **algo_kwargs)
    termination = ("n_eval", max_evals) if max_evals is not None else ("n_gen", n_gen)
    result = minimize(
        problem,
        algorithm,
        termination=termination,
        seed=seed,
        verbose=verbose,
        save_history=False,
    )
    if result.X is None or result.F is None:
        raise RuntimeError("pymoo returned no feasible solutions")
    return ExperimentResult(
        algorithm=algorithm_name,
        seed=seed,
        candidate_pool=problem.candidate_pool,
        X=np.atleast_2d(np.asarray(result.X)),
        F=np.atleast_2d(np.asarray(result.F)),
    )


def save_result(result: ExperimentResult, path: str | Path) -> None:
    """Save a run in a portable NPZ file."""
    np.savez_compressed(
        path,
        X=result.X,
        F=result.F,
        candidate_pool=np.asarray(result.candidate_pool, dtype=str),
        algorithm=result.algorithm,
        seed=result.seed,
    )
