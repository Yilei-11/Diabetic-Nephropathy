"""Objective functions for multiobjective gene-panel selection.

The current nested experiment maximizes panel leanness, inner-CV balanced
accuracy, and a size-normalized GO Biological Process coherence score. The GO
score is an optimization target and target-attainment outcome; it is not used
as independent post-selection biological validation. Pymoo-facing problem
classes negate these scores for minimization.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler


def leanness(panel: list[str]) -> float:
    """1/(n+1); 1.0 for an empty panel, decreasing as the panel grows."""
    return 1.0 / (len(panel) + 1)


def classification_balanced_accuracy(
    panel: list[str],
    expr: pd.DataFrame,
    labels: pd.Series,
    n_splits: int = 5,
    n_repeats: int = 5,
    random_state: int = 0,
    C: float = 0.1,
) -> float:
    """Repeated-cross-validated balanced accuracy of a logistic-regression
    classifier trained on ``panel``'s expression values only. Returns 0.5
    (chance level) for an empty panel rather than raising, since pymoo will
    evaluate the all-zeros individual at least once during initialization.

    ``C=0.1`` (stronger L2 regularization than sklearn's ``C=1.0`` default) is
    used deliberately: with only 61 training samples, even a 30-gene panel
    (the project's hard cap, see ``problem.py``) is a high-dimensional
    p-relative-to-n regime where an unregularized/lightly-regularized
    logistic regression trivially reaches balanced_accuracy=1.0 for almost
    any panel, which the first HPC-scale run showed makes the accuracy
    objective uninformative (it saturates rather than discriminating between
    genuinely good and bad panels). Stronger regularization does not fix
    small-sample overfitting on its own -- see ``nested_validation.py`` for
    the leakage-controlled outer-CV check this should always be paired with
    -- but it keeps this in-loop fitness signal from being flat at 1.0.

    ``n_repeats=5`` (2026-09-18 fix): earlier, this scored every candidate
    panel of an entire EC run against a SINGLE fixed 5-fold split (the whole
    run shared one ``random_state``), so every one of a run's ~10,000
    fitness evaluations measured "how well does this panel fit *this one*
    arbitrary partition of 61 samples" rather than a stable estimate of
    generalization. A follow-up random-gene-panel control (after fixing an
    unrelated panel-size-cap bug) found EC-selected panels statistically
    indistinguishable from, and in several algorithms slightly worse than,
    random same-size gene panels on external validation -- consistent with
    the search chasing that single split's fold-membership noise rather than
    robust signal. Averaging over ``n_repeats`` independent 5-fold partitions
    (still deterministic given ``random_state``, for reproducibility) gives a
    much less noisy fitness signal for the search to climb.
    """
    if len(panel) == 0:
        return 0.5

    X = expr.loc[panel].T.to_numpy()  # samples x genes
    y = labels.loc[expr.columns].to_numpy()

    n_splits = min(n_splits, int(np.bincount(y).min()))
    if n_splits < 2:
        return 0.5

    clf = LogisticRegression(max_iter=1000, C=C)
    pipeline_scores = []
    cv = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=random_state)
    scaler = StandardScaler()
    for train_idx, test_idx in cv.split(X, y):
        X_train = scaler.fit_transform(X[train_idx])
        X_test = scaler.transform(X[test_idx])
        clf.fit(X_train, y[train_idx])
        preds = clf.predict(X_test)
        # balanced accuracy: average of per-class recall
        y_test = y[test_idx]
        recalls = []
        for cls in (0, 1):
            mask = y_test == cls
            if mask.sum() > 0:
                recalls.append((preds[mask] == cls).mean())
        pipeline_scores.append(np.mean(recalls))
    return float(np.mean(pipeline_scores))


@lru_cache(maxsize=1)
def _gene_sets_path() -> str:
    return str(Path(__file__).resolve().parents[2] / "data" / "external" / "genesets" / "GO_Biological_Process_2023.gmt")


@lru_cache(maxsize=1)
def _load_gene_sets() -> tuple[tuple[str, frozenset[str]], ...]:
    """Load the local GMT once for fast repeated objective evaluations."""
    gene_sets = []
    with open(_gene_sets_path(), encoding="utf-8") as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if len(fields) >= 3:
                gene_sets.append((fields[0], frozenset(fields[2:])))
    return tuple(gene_sets)


class GOCoherenceScorer:
    """Mean pairwise GO Biological Process coherence for a gene panel.

    Genes are represented by their memberships in GO BP gene sets after the
    terms are restricted to the current training-split candidate universe.
    Pairwise gene similarity is the Jaccard coefficient of those membership
    profiles. A panel's score is the mean Jaccard similarity across all
    distinct gene pairs. This keeps the score on [0, 1], gives the same null
    expectation at every panel size, and avoids optimizing the most extreme
    nominal enrichment p-value across thousands of GO terms.

    In randomized mode, complete annotation profiles are permuted among
    candidate genes. The null therefore preserves every term size, every
    annotation count, and the full similarity distribution while breaking
    the mapping between gene identity and GO annotation.
    """

    def __init__(
        self,
        background: list[str] | tuple[str, ...],
        *,
        randomized: bool = False,
        random_state: int = 0,
        min_term_size: int = 3,
        max_term_fraction: float = 0.5,
    ) -> None:
        self.genes = tuple(dict.fromkeys(background))
        self.index = {gene: i for i, gene in enumerate(self.genes)}
        n_genes = len(self.genes)
        max_term_size = max(min_term_size, int(np.floor(max_term_fraction * n_genes)))

        rows: list[int] = []
        cols: list[int] = []
        term_index = 0
        background_set = set(self.genes)
        for _, raw_genes in _load_gene_sets():
            members = raw_genes & background_set
            if min_term_size <= len(members) <= max_term_size:
                rows.extend(self.index[gene] for gene in members)
                cols.extend([term_index] * len(members))
                term_index += 1

        if term_index == 0:
            self.similarity = np.zeros((n_genes, n_genes), dtype=np.float32)
            return

        membership = sparse.csr_matrix(
            (np.ones(len(rows), dtype=np.float32), (rows, cols)),
            shape=(n_genes, term_index),
        )
        intersections = (membership @ membership.T).toarray().astype(np.float32, copy=False)
        degree = np.asarray(membership.sum(axis=1)).ravel()
        unions = degree[:, None] + degree[None, :] - intersections
        similarity = np.divide(
            intersections,
            unions,
            out=np.zeros_like(intersections, dtype=np.float32),
            where=unions > 0,
        )
        np.fill_diagonal(similarity, 0.0)
        if randomized and n_genes > 1:
            permutation = np.random.default_rng(random_state).permutation(n_genes)
            similarity = similarity[np.ix_(permutation, permutation)]
        self.similarity = similarity

    def score(self, panel: list[str] | tuple[str, ...]) -> float:
        indices = np.fromiter(
            (self.index[gene] for gene in dict.fromkeys(panel) if gene in self.index),
            dtype=int,
        )
        if len(indices) < 2:
            return 0.0
        within = self.similarity[np.ix_(indices, indices)]
        # The diagonal is zero and the matrix is symmetric. Dividing its full
        # sum by k(k-1) is therefore the mean over all unordered gene pairs.
        k = len(indices)
        return float(within.sum() / (k * (k - 1)))


def pathway_relevance(panel: list[str], background: tuple[str, ...]) -> float:
    """Backward-compatible wrapper for the real-GO coherence score."""
    return GOCoherenceScorer(background).score(panel)
