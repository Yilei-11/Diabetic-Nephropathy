"""Leakage-controlled nested cross-validation (internal evaluation) for one algorithm.

DEG screening and evolutionary search happen exclusively inside each outer
training fold; the outer test fold is scored once and never consulted during
Panel selection. See nested_validation.nested_cross_validate for details.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from dn_moea.geo_data import load_gse30528, load_gse96804  # noqa: E402
from dn_moea.nested_validation import nested_cross_validate  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithm", required=True)
    parser.add_argument("--pop-size", type=int, default=100)
    parser.add_argument("--n-gen", type=int, default=100)
    parser.add_argument("--n-splits", type=int, default=5)
    parser.add_argument("--split-seed", type=int, default=2026)
    parser.add_argument("--max-pool-size", type=int, default=2000)
    parser.add_argument("--max-panel-size", type=int, default=30)
    parser.add_argument("--output-dir", type=Path, default=Path("results/nested_cv"))
    parser.add_argument(
        "--swap-datasets",
        action="store_true",
        help="Run nested CV on GSE30528 instead of GSE96804 (the reversed-role "
        "robustness check). Still confounded by GSE30528's own internal "
        "GSM-order/label batch structure -- nested CV within either single "
        "dataset is not a fix for that, only cross-dataset transfer is.",
    )
    args = parser.parse_args()

    expr, labels = load_gse30528() if args.swap_datasets else load_gse96804()
    report = nested_cross_validate(
        expr,
        labels,
        expr.index,
        algorithm_name=args.algorithm,
        pop_size=args.pop_size,
        n_gen=args.n_gen,
        n_splits=args.n_splits,
        seed=args.split_seed,
        max_pool_size=args.max_pool_size,
        max_panel_size=args.max_panel_size,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report.insert(0, "algorithm", args.algorithm)
    out_path = args.output_dir / f"{args.algorithm}__nested_cv.csv"
    report.to_csv(out_path, index=False)
    print(f"completed {args.algorithm}: mean_ext_acc={report['external_balanced_accuracy'].mean():.4f}")
    print(report.to_string(index=False))


if __name__ == "__main__":
    main()
