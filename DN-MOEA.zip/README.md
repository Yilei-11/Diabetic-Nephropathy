# dn-gene-panel-moea

Multi-objective evolutionary search for sparse, biologically coherent gene panels for diabetic nephropathy (DN) classification, evaluated with leakage-controlled nested cross-validation and external cohort transfer.

Six MOEAs, spanning three mechanism families, are implemented as `pymoo` extensions and benchmarked against each other and against random/top-DEG panel baselines:

| Family              | Classic baseline | Variant                       |
|---------------------|-------------------|-------------------------------|
| Dominance + crowding| NSGA-II           | NSGA-II with balanced tie-break |
| Strength + archive  | SPEA2             | SPEA2+                        |
| Decomposition       | MOEA/D            | MOEA/D-NRD                    |

Objectives: panel leanness, cross-validated balanced classification accuracy, and Gene Ontology (Biological Process) coherence.

## Install

```bash
pip install -r requirements.txt
```

## Data

All gene-expression data is public and is downloaded automatically on first use via [`GEOparse`](https://github.com/guma44/GEOparse) into `data/external/GEO/` (not checked into this repo):

- **GSE96804** — primary training/search cohort (41 DN vs. 20 control glomeruli)
- **GSE30528** — external validation cohort (9 DN vs. 13 control glomeruli)

A Gene Ontology Biological Process 2023 gene-set library (`data/external/genesets/GO_Biological_Process_2023.gmt`, from [Enrichr](https://maayanlab.cloud/Enrichr/#libraries)) is included for the pathway-coherence objective.

A third cohort, **GSE142025** (RNA-seq), is supported by `dn_moea.geo_data.load_gse142025` but requires its expression matrix to be extracted separately from that series' supplementary RNA-seq archive (GEO does not embed per-sample RNA-seq values in the SOFT file); this step is not included here.

## Usage

Run a single algorithm/seed panel search (writes the Pareto set and external-validation metrics to `--output-dir`):

```bash
python run_dk_panel_task.py --algorithm nsga2_tiebreak --seed 0 \
  --pop-size 100 --max-evals 10000 --max-pool-size 2000 --max-panel-size 30 \
  --output-dir results/panel_search
```

`--algorithm` is one of `nsga2`, `nsga2_tiebreak`, `spea2`, `spea2_plus`, `moead`, `moead_nrd`.

Run leakage-controlled nested cross-validation for one algorithm (DEG screening and panel search happen strictly inside each outer training fold):

```bash
python run_nested_cv.py --algorithm nsga2_tiebreak \
  --n-splits 5 --pop-size 100 --n-gen 100 --output-dir results/nested_cv
```

## Tests

```bash
pytest
```

The test suite is fully offline (no GEO download required).

## License

MIT — see `LICENSE`.
