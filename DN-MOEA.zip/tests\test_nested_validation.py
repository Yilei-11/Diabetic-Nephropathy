import numpy as np
import pandas as pd

from dn_moea.nested_validation import nested_cross_validate


def test_nested_validation_keeps_one_row_per_outer_fold():
    rng = np.random.default_rng(3)
    genes = [f"G{i}" for i in range(6)]
    samples = [f"S{i}" for i in range(12)]
    labels = pd.Series([0] * 6 + [1] * 6, index=samples)
    expr = pd.DataFrame(rng.normal(size=(6, 12)), index=genes, columns=samples)
    expr.loc["G0", labels == 1] += 3.0

    report = nested_cross_validate(
        expr,
        labels,
        pd.Index(genes),
        pop_size=4,
        n_gen=1,
        n_splits=2,
        max_pool_size=6,
        seed=2,
    )

    assert report.shape[0] == 2
    assert set(report.columns) == {
        "fold",
        "candidate_pool_size",
        "panel_size",
        "external_balanced_accuracy",
        "external_auc",
        "genes",
    }
    assert np.all((report.external_balanced_accuracy >= 0.0) & (report.external_balanced_accuracy <= 1.0))
    assert np.all((report.external_auc >= 0.0) & (report.external_auc <= 1.0))

