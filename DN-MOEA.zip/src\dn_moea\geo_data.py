"""Load the two diabetic nephropathy (DN) GEO datasets used by this project
into a common (expression-by-gene, sample labels) form.

GSE96804 (primary training/search set): 41 DN vs. 20 control glomeruli,
Affymetrix Human Transcriptome Array 2.0 (platform GPL17586), exon-level
transcript-cluster probes. Group label lives in each sample's
``source_name_ch1`` field ("diabetic nephropathy" vs. "unaffected portion of
tumor nephrectomies").

GSE30528 (sole external validation set): 9 DN vs. 13 control glomeruli,
Affymetrix HG-U133A_2 (platform GPL571), classic 3'-biased probes. Group
label lives in each sample's ``characteristics_ch1`` field
("disease state: diabetic kidney disease (DKD)" vs. "disease state:
control").

Both platforms' probes are mapped to HGNC gene symbols and aggregated (mean
across probes/probesets mapping to the same gene) so that GSE96804-derived
gene panels can be looked up directly in GSE30528 by gene symbol, despite the
two datasets using entirely different probe technologies.
"""
from __future__ import annotations

import logging
from pathlib import Path

import GEOparse
import numpy as np
import pandas as pd

logging.getLogger("GEOparse").setLevel(logging.WARNING)

DATA_DIR = Path(__file__).resolve().parents[2] / "data" / "external" / "GEO"


def _load_gse(geo_id: str):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return GEOparse.get_GEO(geo=geo_id, destdir=str(DATA_DIR), silent=True)


def _expression_matrix(gse) -> pd.DataFrame:
    """Probe-by-sample matrix, columns=GSM accessions, index=probe/probeset ID."""
    series = {}
    for gsm_name, gsm in gse.gsms.items():
        table = gsm.table.set_index("ID_REF")["VALUE"]
        series[gsm_name] = table
    return pd.DataFrame(series)


def _map_gpl571_to_gene_symbol(gse) -> pd.Series:
    """probe ID -> gene symbol, for the classic 3'-array GPL571 platform
    (GSE30528), which already has a clean ``Gene Symbol`` annotation column."""
    gpl = next(iter(gse.gpls.values()))
    ann = gpl.table.set_index("ID")["Gene Symbol"]
    return ann.replace("", np.nan).dropna()


def _parse_hta_gene_assignment(gene_assignment: str) -> str | None:
    """Extract a single gene symbol from GPL17586's compound
    ``gene_assignment`` field, e.g.
    ``"NM_001123377 // PARK7 // parkinson protein 7 // 1p36.23 // 11315 /// ..."``
    -> ``"PARK7"``. Returns None for unannotated probes (``"---"``) or
    intergenic/NULL entries with no usable symbol.
    """
    if not isinstance(gene_assignment, str) or gene_assignment.strip() == "---":
        return None
    for block in gene_assignment.split(" /// "):
        fields = block.split(" // ")
        if len(fields) >= 2:
            symbol = fields[1].strip()
            if symbol and symbol not in ("---", "NULL"):
                return symbol
    return None


def _map_gpl17586_to_gene_symbol(gse) -> pd.Series:
    """probeset ID -> gene symbol, for the exon-array GPL17586 platform
    (GSE96804), parsed from the compound ``gene_assignment`` field."""
    gpl = next(iter(gse.gpls.values()))
    symbols = gpl.table.set_index("ID")["gene_assignment"].map(_parse_hta_gene_assignment)
    return symbols.dropna()


def _aggregate_to_gene_level(probe_expr: pd.DataFrame, probe_to_gene: pd.Series) -> pd.DataFrame:
    """Collapse a probe-by-sample matrix to a gene-by-sample matrix by
    averaging all probes/probesets that map to the same gene symbol."""
    common = probe_expr.index.intersection(probe_to_gene.index)
    mapped = probe_expr.loc[common].copy()
    mapped["__gene__"] = probe_to_gene.loc[common].to_numpy()
    return mapped.groupby("__gene__").mean()


def _labels_from_source_name(gse) -> pd.Series:
    """GSE96804-style label: ``source_name_ch1`` is "diabetic nephropathy" or
    "unaffected portion of tumor nephrectomies". Returns 1=DN, 0=control."""
    labels = {}
    for gsm_name, gsm in gse.gsms.items():
        source = gsm.metadata.get("source_name_ch1", [""])[0]
        if "diabetic nephropathy" in source:
            labels[gsm_name] = 1
        elif "nephrectom" in source:
            labels[gsm_name] = 0
        else:
            raise ValueError(f"Unrecognized source_name_ch1 for {gsm_name}: {source!r}")
    return pd.Series(labels, name="label")


def _labels_from_characteristics(gse) -> pd.Series:
    """GSE30528-style label: ``characteristics_ch1`` contains a "disease
    state: ..." entry, either "diabetic kidney disease (DKD)" or "control".
    Returns 1=DKD, 0=control."""
    labels = {}
    for gsm_name, gsm in gse.gsms.items():
        chars = gsm.metadata.get("characteristics_ch1", [])
        disease_state = next((c for c in chars if c.startswith("disease state:")), None)
        if disease_state is None:
            raise ValueError(f"No 'disease state' characteristic for {gsm_name}")
        if "DKD" in disease_state:
            labels[gsm_name] = 1
        elif "control" in disease_state:
            labels[gsm_name] = 0
        else:
            raise ValueError(f"Unrecognized disease state for {gsm_name}: {disease_state!r}")
    return pd.Series(labels, name="label")


def load_gse96804() -> tuple[pd.DataFrame, pd.Series]:
    """Primary training/search dataset. Returns (genes x samples expression
    matrix, sample labels [1=DN, 0=control]), both indexed/ordered by the
    same 61 GSM accessions."""
    gse = _load_gse("GSE96804")
    probe_expr = _expression_matrix(gse)
    probe_to_gene = _map_gpl17586_to_gene_symbol(gse)
    gene_expr = _aggregate_to_gene_level(probe_expr, probe_to_gene)
    labels = _labels_from_source_name(gse)
    return gene_expr[labels.index], labels


def load_gse30528() -> tuple[pd.DataFrame, pd.Series]:
    """Sole external validation dataset. Returns (genes x samples expression
    matrix, sample labels [1=DKD, 0=control]), both indexed/ordered by the
    same 22 GSM accessions."""
    gse = _load_gse("GSE30528")
    probe_expr = _expression_matrix(gse)
    probe_to_gene = _map_gpl571_to_gene_symbol(gse)
    gene_expr = _aggregate_to_gene_level(probe_expr, probe_to_gene)
    labels = _labels_from_characteristics(gse)
    return gene_expr[labels.index], labels


def _labels_from_group_characteristic(gse) -> pd.Series:
    """GSE142025-style label: ``characteristics_ch1`` contains a
    "group: Early_DN|Advanced_DN|Control" entry. Early- and advanced-stage DN
    are merged into a single DN=1 label (this project's other two cohorts are
    binary DN-vs-control; GSE142025's own stage split is available separately
    via ``load_gse142025(merge_dn_stages=False)`` for future staging work).
    Returns 1=DN (early or advanced), 0=control."""
    labels = {}
    for gsm_name, gsm in gse.gsms.items():
        chars = gsm.metadata.get("characteristics_ch1", [])
        group = next((c for c in chars if c.startswith("group:")), None)
        if group is None:
            raise ValueError(f"No 'group' characteristic for {gsm_name}")
        value = group.split(":", 1)[1].strip()
        if value in ("Early_DN", "Advanced_DN"):
            labels[gsm_name] = 1
        elif value == "Control":
            labels[gsm_name] = 0
        else:
            raise ValueError(f"Unrecognized group for {gsm_name}: {value!r}")
    return pd.Series(labels, name="label")


def load_gse142025(*, merge_dn_stages: bool = True) -> tuple[pd.DataFrame, pd.Series]:
    """Second, larger external validation cohort (added 2026-09-19).

    36 kidney-biopsy samples (9 control, 6 early DN, 21 advanced DN), RNA-seq
    (GPL20301), STAR-aligned / log2-transformed / quantile-normalized read
    counts -- a genuinely different assay technology from both GSE96804
    (Affymetrix HTA 2.0) and GSE30528 (Affymetrix HG-U133A_2, GPL571), so a
    panel that transfers here crosses a bigger technical gap than transferring
    between the two microarray cohorts alone.

    Expression values are read from a pre-extracted, gene-symbol-indexed
    matrix (``data/external/GEO/GSE142025_expr.pkl``) rather than parsed from
    the SOFT file directly: this is an RNA-seq series, so (unlike GSE96804 and
    GSE30528) GEO does not embed per-sample expression rows in the SOFT
    file's own GSM data tables -- the actual matrix lives in a series-level
    supplementary archive (``GSE142025_RAW.tar``) that a normalized-counts
    matrix was previously extracted from. Labels, however, are derived here
    directly from the SOFT file's own ``characteristics_ch1`` metadata (not
    trusted from a companion labels pickle), and verified byte-for-byte
    against that pre-extracted pickle's own labels before use, so a stale or
    mismatched cache is caught rather than silently trusted.

    Returns (genes x samples expression matrix, sample labels [1=DN, 0=control
    if ``merge_dn_stages`` (default); otherwise 1=Advanced_DN, 0=Early_DN,
    with control samples dropped]), both indexed/ordered by the same 36 (or
    30, if stages are not merged) GSM accessions.
    """
    import pickle

    gse = _load_gse("GSE142025")
    expr_path = DATA_DIR / "GSE142025_expr.pkl"
    if not expr_path.exists():
        raise FileNotFoundError(
            f"{expr_path} not found -- GSE142025's RNA-seq expression matrix "
            "must be extracted from its series supplementary archive "
            "(GSE142025_RAW.tar) separately; it is not embedded in the SOFT "
            "file GEOparse loads."
        )
    with expr_path.open("rb") as handle:
        gene_expr: pd.DataFrame = pickle.load(handle)

    binary_labels = _labels_from_group_characteristic(gse)

    labels_cache_path = DATA_DIR / "GSE142025_labels.pkl"
    if labels_cache_path.exists():
        with labels_cache_path.open("rb") as handle:
            cached_labels = pickle.load(handle)
        cached_binary = cached_labels.map(
            lambda v: 0 if v == "Control" else (1 if v in ("Early_DN", "Advanced_DN") else None)
        )
        common = binary_labels.index.intersection(cached_binary.index)
        if not common.equals(binary_labels.index) or not (
            binary_labels.loc[common] == cached_binary.loc[common]
        ).all():
            raise ValueError(
                "GSE142025 labels derived from the SOFT file's own metadata "
                "do not match the cached GSE142025_labels.pkl -- data may be "
                "stale or mismatched; refusing to silently proceed."
            )

    if merge_dn_stages:
        labels = binary_labels
    else:
        with labels_cache_path.open("rb") as handle:
            stage_labels = pickle.load(handle)
        stage_labels = stage_labels[stage_labels != "Control"]
        labels = stage_labels.map({"Advanced_DN": 1, "Early_DN": 0}).astype(int)
        labels.name = "label"

    common_samples = gene_expr.columns.intersection(labels.index)
    return gene_expr[common_samples], labels.loc[common_samples]
