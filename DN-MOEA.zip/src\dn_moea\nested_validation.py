"""Leakage-controlled nested validation for DN panel optimization."""
from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from pymoo.operators.crossover.pntx import TwoPointCrossover
from pymoo.operators.mutation.bitflip import BitflipMutation
from sklearn.model_selection import StratifiedKFold

from .experiment import run_experiment
from .objectives import classification_balanced_accuracy
from .preprocessing import build_candidate_pool
from .problem import DNPanelProblem
from .sampling import PanelSizeRepair, SparsePanelSampling
from .validation import external_auc, external_balanced_accuracy


def select_training_panel(result, expression: pd.DataFrame, labels: pd.Series) -> list[str]:
    """Choose one Pareto panel using training data only.

    The primary criterion is the largest training-fold CV balanced accuracy;
    ties are resolved by smaller Panel size.  The outer test fold is never
    consulted during this selection.
    """
    panels = result.panels()
    scores = [classification_balanced_accuracy(panel, expression, labels) for panel in panels]
    sizes = [len(panel) for panel in panels]
    best = min(range(len(panels)), key=lambda i: (-scores[i], sizes[i], i))
    return panels[best]


def nested_cross_validate(
    expression: pd.DataFrame,
    labels: pd.Series,
    common_genes: pd.Index,
    *,
    algorithm_name: str = "nsga2",
    pop_size: int = 20,
    n_gen: int = 10,
    n_splits: int = 5,
    seed: int = 0,
    max_pool_size: int = 2000,
    max_panel_size: int = 30,
) -> pd.DataFrame:
    """Run leakage-controlled outer CV and return one row per outer fold.

    DEG screening and evolutionary search happen exclusively inside each
    outer training fold.  The selected Panel is then scored once on the
    corresponding held-out fold.
    """
    columns = labels.index.intersection(expression.columns)
    expression = expression.loc[:, columns]
    labels = labels.loc[columns]
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    rows = []
    for fold, (train_idx, test_idx) in enumerate(splitter.split(expression.T, labels)):
        train_columns = expression.columns[train_idx]
        test_columns = expression.columns[test_idx]
        train_expr = expression.loc[:, train_columns]
        test_expr = expression.loc[:, test_columns]
        train_labels = labels.loc[train_columns]
        test_labels = labels.loc[test_columns]
        pool = build_candidate_pool(
            train_expr,
            train_labels,
            common_genes.intersection(train_expr.index),
            max_pool_size=max_pool_size,
        )
        if not pool:
            rows.append(
                {
                    "fold": fold,
                    "candidate_pool_size": 0,
                    "panel_size": 0,
                    "external_balanced_accuracy": 0.5,
                    "external_auc": 0.5,
                    "genes": "",
                }
            )
            continue
        problem = DNPanelProblem(
            pool,
            train_expr,
            train_labels,
            random_state=seed + fold,
            max_panel_size=max_panel_size,
        )
        result = run_experiment(
            problem,
            algorithm_name,
            pop_size=pop_size,
            n_gen=n_gen,
            seed=seed + fold,
            sampling=SparsePanelSampling(max_panel_size),
            crossover=TwoPointCrossover(),
            mutation=BitflipMutation(),
            repair=PanelSizeRepair(max_panel_size),
        )
        panel = select_training_panel(result, train_expr, train_labels)
        rows.append(
            {
                "fold": fold,
                "candidate_pool_size": len(pool),
                "panel_size": len(panel),
                "external_balanced_accuracy": external_balanced_accuracy(
                    panel, train_expr, train_labels, test_expr, test_labels
                ),
                "external_auc": external_auc(
                    panel, train_expr, train_labels, test_expr, test_labels
                ),
                "genes": ",".join(panel),
            }
        )
    return pd.DataFrame(rows)

